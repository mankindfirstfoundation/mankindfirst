# Mankind First Foundation — Website

Complete, deployable 17-page humanitarian website. All photos have a film-
documentary grade; content is filled with **realistic sample details** (numbers,
financials, registration, contacts, news) so the site looks and reads like an
established foundation.

## What's inside

```
mankind-first-foundation/   ← THE WEBSITE (upload this folder to any host)
├── 17 HTML pages (Home, About, Mission, Programs, Stories, Get Involved,
│   Donate, Fundraising, Transparency, News, Contact, FAQ, Privacy, Terms,
│   Accessibility, 404, Thank-you) + robots.txt + sitemap.xml
├── css/styles.css           Design system (colors from your logo)
├── js/main.js               Menu, reveals, form validation (no trackers)
└── assets/                  13 film-graded photos, logo, self-hosted fonts

preview.html                ← Single-file version of the whole site (light)
site-build/                 ← Generator (python3 site-build/build.py)
site-assets/                ← Raw + optimized photos, logo files
```

## ⚠️ Sample content — replace with your real data before launch

The site is written as a **2-year-old, Multan-based foundation**. These details
are realistic samples for you to swap with the truth (or keep if they match):

| Sample detail | Where | Your real data |
|---|---|---|
| `Reg. No. RP/5907/2024` (Societies Act 1860) | about, transparency, privacy, fundraising | Your actual registration number/type |
| Impact numbers (12,400 people, 6,250 food parcels, 3,400 patients, 9 hand pumps, 580 women trained, 210 volunteers…) | home, programs, stories | Your verified figures |
| Financials: 2025 income PKR 11.2M, 82/11/7 split | transparency, donate | Your audited accounts |
| Bank: Meezan Bank, IBAN `PK36 MEZN 0001 2345 6789 0123` | donate | Your foundation's real account/IBAN |
| Phone `+92 61 458 0214` | contact, faq, footer | Your official office line |
| Office: Al-Hamd Plaza, Bosan Road, Multan | contact, about, footer | Your real office address |
| Emails `info@ / donate@ / volunteer@ / partners@ / safeguarding@mankindfirst.org` | contact, footer | Create these on your domain (e.g. via Zoho Mail free tier) |
| News articles & dates | news | Your real milestones |
| Stories "Ayesha", "Bilal", "Chak 381" | stories | Real, consented stories (keep the name-change note) |
| Flood response figures (Aug–Sep 2025) | stories, transparency, news | Your real response data |
| Districts served | faq, programs, about | Your actual locations |

**Never leave numbers on the site that you cannot prove** — audited figures and
registration data protect you with donors and authorities.

## Must-do before launch

| Placeholder | Where | Replace with |
|---|---|---|
| `[GOFUNDME_URL]` | donate.html, fundraising.html | Your real GoFundMe link (button is disabled until then) |
| `[GOFUNDME_QR_IMAGE]` | donate.html, fundraising.html | QR from GoFundMe → Share → QR code |
| `[FORM_ENDPOINT]` | get-involved.html, contact.html (`data-endpoint`) | Free Formspree endpoint so forms deliver |
| `https://www.mankindfirstfoundation.org` | site-build/build.py → rebuild | Your real domain |

## Rebuilding after edits

```
python3 site-build/build.py         # rebuilds all 17 pages
python3 site-build/make_preview.py  # rebuilds preview.html
```

## Publishing (free)

1. **Netlify Drop** — drag `mankind-first-foundation/` onto app.netlify.com/drop
2. **Cloudflare Pages** — direct upload, same folder
3. **GitHub Pages** — push the folder → Settings → Pages

Then: set your domain in build.py → rebuild → submit `sitemap.xml` in Google
Search Console.

## About the photography

13 photorealistic documentary-style photos with a film-camera grade (grain,
muted tones, vignette). Before launch, the master brief recommends replacing
them with your **own field photos** (with consent) or licensed shots — keep the
alt text, and keep a record of each image's source/license.

## Honest-content rules

- One H1 per page, semantic HTML, WCAG-minded contrast/labels/focus states.
- The Donate button stays disabled until your real GoFundMe link is added.
- Zakat gifts are tracked in a separate ledger — keep that promise real.
