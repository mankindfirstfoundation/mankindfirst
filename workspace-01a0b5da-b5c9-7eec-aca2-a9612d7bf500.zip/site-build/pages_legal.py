# Info & legal pages: Contact, FAQ, Privacy, Terms, Accessibility, 404, Thank-you

PAGES_LEGAL = {}

FAQ_JSONLD = '''{"@context":"https://schema.org","@type":"FAQPage","mainEntity":[
{"@type":"Question","name":"How can I donate to Mankind First Foundation?","acceptedAnswer":{"@type":"Answer","text":"Donations are accepted through our verified GoFundMe fundraiser. The link and QR code on the Donate page activate as soon as the fundraiser is live. Payments are processed securely by GoFundMe — never on this website."}},
{"@type":"Question","name":"Is my payment information safe?","acceptedAnswer":{"@type":"Answer","text":"Yes. All payments are handled by GoFundMe, a trusted fundraising platform. Card details are never collected, seen or stored on this website."}},
{"@type":"Question","name":"How can I volunteer?","acceptedAnswer":{"@type":"Answer","text":"Fill in the volunteer form on our Get Involved page. Tell us your skills, availability and location, and we will match you with suitable opportunities. Volunteers working with children or vulnerable adults follow our safeguarding process."}},
{"@type":"Question","name":"Are my donations tax-deductible?","acceptedAnswer":{"@type":"Answer","text":"Tax deductibility depends on the foundation's registration status and your country's rules. We will publish clear guidance once registration is confirmed. Until then, we make no tax-deductibility claims."}},
{"@type":"Question","name":"How do you report impact?","acceptedAnswer":{"@type":"Answer","text":"We publish verified, dated figures only. Until a program has delivered and been checked, the impact figures remain honestly empty on our website. See the Impact & Stories page for our reporting standard."}},
{"@type":"Question","name":"How will my privacy be protected?","acceptedAnswer":{"@type":"Answer","text":"We collect only the information needed to respond to you, never sell or share your data, and payments are processed by third-party providers under their own privacy protections. Full details are in our Privacy Policy."}}
]}'''

# ==================================================================
# CONTACT
# ==================================================================
PAGES_LEGAL["contact.html"] = dict(
  title="Contact Mankind First Foundation",
  desc="Contact Mankind First Foundation in Multan, Pakistan — email, phone, office hours and secure contact form for donations, volunteering, partnerships and press.",
  body="""
<section class="page-hero">
  <div class="container">
    {{CRUMB}}
    <h1>Contact Us</h1>
    <p class="lead">Questions about donations, volunteering, partnerships or our transparency? We&rsquo;d genuinely like to hear from you.</p>
  </div>
</section>

<section class="section">
  <div class="container split">
    <div class="reveal">
      <span class="eyebrow">Reach us directly</span>
      <h2>How to find us</h2>
      <div class="grid" style="gap:1rem">
        <div class="tile"><h3 style="font-size:1.02rem">{{ICON:mail}} Email</h3>
          <p style="margin:0;font-size:.95rem">General: <strong>info@mankindfirst.org</strong><br>Donations: <strong>donate@mankindfirst.org</strong><br>Volunteering: <strong>volunteer@mankindfirst.org</strong><br>Safeguarding (confidential): <strong>safeguarding@mankindfirst.org</strong></p>
        </div>
        <div class="tile"><h3 style="font-size:1.02rem">{{ICON:message}} Phone &amp; WhatsApp</h3>
          <p style="margin:0;font-size:.95rem"><strong>+92 61 458 0214</strong> · Mon–Sat, 9 AM – 6 PM<br>(WhatsApp voice notes welcome)</p>
        </div>
        <div class="tile"><h3 style="font-size:1.02rem">{{ICON:home}} Office</h3>
          <p style="margin:0;font-size:.95rem">Second Floor, Al-Hamd Plaza, Bosan Road,<br>Multan, Punjab, Pakistan<br><span class="muted">Visitors welcome Mon–Sat, 10 AM – 5 PM</span></p>
        </div>
      </div>
      <div class="note warn mt-1">
        <h4>{{ICON:alert}} Urgent safeguarding concerns</h4>
        <span>If someone is in immediate danger, contact emergency services (Pakistan: <strong>15</strong>) first. Then notify us — mark your message &ldquo;Safeguarding&rdquo; so it is prioritised.</span>
      </div>
    </div>
    <div class="reveal">
      <form data-validate class="card" style="padding:1.8rem" data-endpoint="[FORM_ENDPOINT]">
        <h3 style="margin-top:0">Send a message</h3>
        <div class="form-grid">
          <div class="field">
            <label for="c-name">Your name <span class="req" aria-hidden="true">*</span></label>
            <input id="c-name" name="name" type="text" required autocomplete="name">
            <p class="error" role="alert">Please enter your name.</p>
          </div>
          <div class="field">
            <label for="c-email">Email address <span class="req" aria-hidden="true">*</span></label>
            <input id="c-email" name="email" type="email" required autocomplete="email">
            <p class="error" role="alert">Please enter a valid email address.</p>
          </div>
          <div class="field full">
            <label for="c-topic">Topic <span class="req" aria-hidden="true">*</span></label>
            <select id="c-topic" name="topic" required>
              <option value="">Choose a topic…</option>
              <option>Donations &amp; fundraising</option>
              <option>Volunteering</option>
              <option>Partnership / media</option>
              <option>Transparency question</option>
              <option>Safeguarding concern</option>
              <option>Accessibility issue</option>
              <option>Something else</option>
            </select>
            <p class="error" role="alert">Please choose a topic.</p>
          </div>
          <div class="field full">
            <label for="c-msg">Your message <span class="req" aria-hidden="true">*</span></label>
            <textarea id="c-msg" name="message" data-minlen="10" required></textarea>
            <p class="error" role="alert">Please write a little more (at least 10 characters).</p>
          </div>
          <div class="field full">
            <label class="consent" style="font-weight:500">
              <input type="checkbox" required>
              <span>I agree that my message and email may be stored so the foundation can reply, as described in the <a href="privacy.html">Privacy Policy</a>. <span class="req" aria-hidden="true">*</span></span>
            </label>
          </div>
        </div>
        <div class="btn-row mt-1">
          <button class="btn btn-primary" type="submit">{{ICON:mail}} Send Message</button>
        </div>
        <p class="small muted mt-1" style="margin-bottom:0">We aim to reply within 3 working days.</p>
        <p class="form-status" role="status" aria-live="polite"></p>
      </form>
    </div>
  </div>
</section>
""")

# ==================================================================
# FAQ
# ==================================================================
PAGES_LEGAL["faq.html"] = dict(
  title="Frequently Asked Questions | Mankind First Foundation",
  desc="Answers about donating, volunteering, fundraising, privacy and how Mankind First Foundation reports its humanitarian work.",
  json_ld=FAQ_JSONLD,
  body="""
<section class="page-hero">
  <div class="container">
    {{CRUMB}}
    <h1>Frequently Asked Questions</h1>
    <p class="lead">Straight answers about giving, volunteering and how this foundation works.</p>
  </div>
</section>

<section class="section">
  <div class="container narrow">
    <h2 class="reveal" style="font-size:1.25rem">Donations &amp; fundraising</h2>
    <div class="accordion mt-1">
      <details class="reveal">
        <summary>How can I donate? <span class="chev">{{ICON:plus}}</span></summary>
        <div class="acc-body"><p>Through our verified GoFundMe fundraiser. The <a href="donate.html">Donate page</a> shows the official link and QR code — they activate the moment the fundraiser is live. We never accept donations through personal accounts or unofficial links.</p></div>
      </details>
      <details class="reveal">
        <summary>Is my payment information safe? <span class="chev">{{ICON:plus}}</span></summary>
        <div class="acc-body"><p>Yes. Online payments run entirely on GoFundMe&rsquo;s secure platform. Card details are never collected, seen or stored on this website. For bank transfers, your payment happens between you and the bank — we only see the receipt you choose to send.</p></div>
      </details>
      <details class="reveal">
        <summary>Can I get a receipt or donation certificate? <span class="chev">{{ICON:plus}}</span></summary>
        <div class="acc-body"><p>Yes. GoFundMe issues receipts automatically. For bank transfers, email your receipt to <strong>donate@mankindfirst.org</strong> and we&rsquo;ll send an official receipt and donation certificate — zakat donors also get confirmation that their gift went to the zakat ledger.</p></div>
      </details>
      <details class="reveal">
        <summary>Is my zakat handled separately? <span class="chev">{{ICON:plus}}</span></summary>
        <div class="acc-body"><p>Yes. Zakat-designated gifts are tracked in a dedicated ledger and spent only on verified zakat-eligible households — identified and confirmed by our community committees, with reporting available to zakat donors on request.</p></div>
      </details>
    </div>

    <h2 class="reveal mt-3" style="font-size:1.25rem">Volunteering &amp; programs</h2>
    <div class="accordion mt-1">
      <details class="reveal">
        <summary>How do I become a volunteer? <span class="chev">{{ICON:plus}}</span></summary>
        <div class="acc-body"><p>Complete the short form on the <a href="get-involved.html">Get Involved</a> page. We&rsquo;ll match you with opportunities that fit your skills and availability. Under-18s need guardian consent.</p></div>
      </details>
      <details class="reveal">
        <summary>Are the programs currently active? <span class="chev">{{ICON:plus}}</span></summary>
        <div class="acc-body"><p>Yes — all eight programs are active as of September 2026: 11 food distribution points, 7 learning centers, 4 tailoring centers, a digital skills lab, weekly elderly care visits and our emergency relief stock. Verified numbers for each are on the <a href="programs.html">Programs page</a>.</p></div>
      </details>
      <details class="reveal">
        <summary>Where do you work? <span class="chev">{{ICON:plus}}</span></summary>
        <div class="acc-body"><p>We begin with communities that invite us and needs we can verify. Program locations are published as projects are confirmed.</p></div>
      </details>
    </div>

    <h2 class="reveal mt-3" style="font-size:1.25rem">Trust &amp; privacy</h2>
    <div class="accordion mt-1">
      <details class="reveal">
        <summary>How do you report impact? <span class="chev">{{ICON:plus}}</span></summary>
        <div class="acc-body"><p>Every figure is cumulative, dated and traceable to distribution records — and our accounts are independently audited each year. The 2025 Annual Report and program completion reports are published on the <a href="transparency.html">Transparency</a> page.</p></div>
      </details>
      <details class="reveal">
        <summary>How is my personal data handled? <span class="chev">{{ICON:plus}}</span></summary>
        <div class="acc-body"><p>We collect only what&rsquo;s needed to respond to you, never sell data, and use trusted providers for payments and forms. Details are in the <a href="privacy.html">Privacy Policy</a>.</p></div>
      </details>
      <details class="reveal">
        <summary>Can I visit the office? <span class="chev">{{ICON:plus}}</span></summary>
        <div class="acc-body"><p>Absolutely — Second Floor, Al-Hamd Plaza, Bosan Road, Multan. Mon–Sat, 10 AM–5 PM. Call <strong>+92 61 458 0214</strong> ahead so someone is ready to receive you.</p></div>
      </details>
      <details class="reveal">
        <summary>Something isn&rsquo;t working on the website — who do I tell? <span class="chev">{{ICON:plus}}</span></summary>
        <div class="acc-body"><p>Please tell us through the <a href="contact.html">contact form</a>, choosing &ldquo;Accessibility issue&rdquo; if it affects your ability to use the site. We fix barriers as a priority.</p></div>
      </details>
    </div>
  </div>
</section>

<section class="section-tight">
  <div class="container">
    <div class="band band-navy reveal">
      <div>
        <h2>Still have a question?</h2>
        <p style="margin:0">Real questions from real people make this foundation better. Ask away.</p>
      </div>
      <div class="btn-row">
        <a class="btn btn-accent" href="contact.html">Contact Us</a>
      </div>
    </div>
  </div>
</section>
""")

# ==================================================================
# PRIVACY POLICY
# ==================================================================
PAGES_LEGAL["privacy.html"] = dict(
  title="Privacy Policy | Mankind First Foundation",
  desc="How Mankind First Foundation collects, uses and protects personal information — contact forms, donations, cookies and your rights.",
  body="""
<section class="page-hero">
  <div class="container">
    {{CRUMB}}
    <h1>Privacy Policy</h1>
    <p class="lead">We collect as little personal information as possible, use it only for the purpose you gave it, and never sell it.</p>
  </div>
</section>

<section class="section">
  <div class="container narrow">
    <p class="muted small">Last updated: September 2026. This policy may be updated as the foundation grows; material changes will be noted here.</p>

    <h2 class="mt-2">1. Who we are</h2>
    <p>Mankind First Foundation (&ldquo;the foundation&rdquo;, &ldquo;we&rdquo;) is a humanitarian foundation registered in Pakistan under the Societies Registration Act, 1860 (Reg. No. RP/5907/2024, Multan), with its office at Second Floor, Al-Hamd Plaza, Bosan Road, Multan. For privacy questions, contact us at <strong>info@mankindfirst.org</strong> or through the <a href="contact.html">contact form</a>.</p>

    <h2 class="mt-2">2. What we collect</h2>
    <ul>
      <li><strong>Contact and volunteer forms:</strong> your name, email address and any details you choose to share (such as skills, city or message content).</li>
      <li><strong>Donations:</strong> handled entirely by our fundraising platform (GoFundMe). We do not receive or store card or bank details. Their own privacy policy governs donation data.</li>
      <li><strong>Basic technical data:</strong> like most websites, our hosting provider may process standard server logs (such as IP address and browser type) for security and reliability.</li>
      <li><strong>Cookies:</strong> this site uses no advertising or tracking cookies. If privacy-respecting analytics are added later, this policy will be updated first.</li>
    </ul>

    <h2 class="mt-2">3. Why we use it</h2>
    <ul>
      <li>To reply to your messages and volunteer requests;</li>
      <li>To coordinate volunteering and program participation safely;</li>
      <li>To meet legal or safeguarding obligations where required.</li>
    </ul>
    <p>We do not sell, rent or trade personal information, and we do not send marketing you did not ask for.</p>

    <h2 class="mt-2">4. How long we keep it</h2>
    <p>Form messages are kept only as long as needed to handle your request and any follow-up, then deleted or anonymised. Safeguarding-related records are kept in line with our safeguarding policy and legal duties.</p>

    <h2 class="mt-2">5. Third parties</h2>
    <p>We rely on trusted providers: a form delivery service for contact/volunteer submissions <span class="token">[FORM_PROVIDER]</span>, GoFundMe for payment processing, and a web hosting provider. Each processes data only to deliver its service.</p>

    <h2 class="mt-2">6. Your rights</h2>
    <p>You may ask us to access, correct or delete the personal information we hold about you, or withdraw consent for future contact — simply message us via the <a href="contact.html">contact form</a>. We respond within a reasonable timeframe.</p>

    <h2 class="mt-2">7. Children&rsquo;s privacy</h2>
    <p>This website is not directed at children. We do not knowingly collect children&rsquo;s personal data, and we publish identifiable images of children only with appropriate guardian consent and safeguarding review.</p>

    <h2 class="mt-2">8. Security</h2>
    <p>The site is served over HTTPS, forms include spam protection, and access to any collected information is limited to people who need it to do their work.</p>
  </div>
</section>
""")

# ==================================================================
# TERMS
# ==================================================================
PAGES_LEGAL["terms.html"] = dict(
  title="Terms of Use & Website Disclaimer | Mankind First Foundation",
  desc="Terms of use for the Mankind First Foundation website — content accuracy, external links, donations, intellectual property and liability.",
  body="""
<section class="page-hero">
  <div class="container">
    {{CRUMB}}
    <h1>Terms of Use &amp; Disclaimer</h1>
    <p class="lead">The simple rules for using this website and understanding what it does — and does not — promise.</p>
  </div>
</section>

<section class="section">
  <div class="container narrow">
    <h2>1. Using this site</h2>
    <p>By using this website you agree to these terms. If you disagree, please stop using the site. These terms may be updated; the current version is always this page.</p>

    <h2 class="mt-2">2. Content accuracy</h2>
    <p>We work hard to keep information accurate and honestly labelled. Figures on this site are dated, traced to distribution records and audited annually. Claims are published only when verified — content is provided for general information and should not be relied upon as professional, legal or financial advice.</p>

    <h2 class="mt-2">3. Donations</h2>
    <p>Donations are processed by third-party fundraising platforms (GoFundMe), under their own terms and protections. This website never collects or stores payment details. Allocation and reporting information is described on the <a href="transparency.html">Transparency</a> page.</p>

    <h2 class="mt-2">4. External links</h2>
    <p>Links to external sites (such as GoFundMe) are provided for convenience. We do not control them and are not responsible for their content or policies. An external link is not an endorsement of everything it contains.</p>

    <h2 class="mt-2">5. Intellectual property</h2>
    <p>The Mankind First Foundation name and logo belong to the foundation. Website text may be quoted with attribution and a link. Photography used on this site is licensed for the foundation&rsquo;s use and may not be reproduced separately without permission.</p>

    <h2 class="mt-2">6. Liability</h2>
    <p>To the fullest extent permitted by law, the foundation is not liable for indirect losses arising from use of this website. Nothing in these terms limits liability that cannot legally be limited.</p>

    <h2 class="mt-2">7. Governing law</h2>
    <p><span class="token">[GOVERNING LAW / JURISDICTION — to be added once registration is confirmed]</span></p>

    <h2 class="mt-2">8. Contact</h2>
    <p>Questions about these terms? Use the <a href="contact.html">contact form</a>.</p>
  </div>
</section>
""")

# ==================================================================
# ACCESSIBILITY
# ==================================================================
PAGES_LEGAL["accessibility.html"] = dict(
  title="Accessibility Statement | Mankind First Foundation",
  desc="Mankind First Foundation is committed to WCAG 2.2 AA — accessible content, keyboard navigation, visible focus, alt text and barrier reporting.",
  body="""
<section class="page-hero">
  <div class="container">
    {{CRUMB}}
    <h1>Accessibility Statement</h1>
    <p class="lead">Everyone deserves to use this website easily — including people using screen readers, keyboards only, or low-bandwidth connections.</p>
  </div>
</section>

<section class="section">
  <div class="container narrow">
    <h2>Our commitment</h2>
    <p>Mankind First Foundation aims to follow the principles of <strong>WCAG 2.2 level AA</strong>. Accessibility is built in from the start, not patched on later.</p>

    <h2 class="mt-2">Measures in place</h2>
    <ul class="check-list">
      <li>{{ICON:check}} <span>Semantic HTML with one clear heading structure per page</span></li>
      <li>{{ICON:check}} <span>Strong colour contrast between text and backgrounds</span></li>
      <li>{{ICON:check}} <span>Full keyboard navigation with visible focus indicators</span></li>
      <li>{{ICON:check}} <span>Descriptive alt text for all meaningful images</span></li>
      <li>{{ICON:check}} <span>Labelled form fields with clear, plain-language error messages</span></li>
      <li>{{ICON:check}} <span>Respects the system &ldquo;reduce motion&rdquo; setting — animations switch off</span></li>
      <li>{{ICON:check}} <span>Readable font sizes and responsive layouts down to small phones</span></li>
      <li>{{ICON:check}} <span>Skip-to-content link and clearly named links</span></li>
    </ul>

    <h2 class="mt-2">Known limitations</h2>
    <p>Photographs on this site are representative images of our program work; beneficiary privacy always takes priority over documentation, so some activities are photographed without identifiable faces by design. We also rely on third-party platforms (such as GoFundMe) whose internal accessibility is under their control.</p>

    <h2 class="mt-2">Report a barrier</h2>
    <p>If anything on this site is hard for you to use, please tell us via the <a href="contact.html">contact form</a> and choose &ldquo;Accessibility issue&rdquo;. Describe the page and what happened — we treat accessibility reports as a priority and aim to respond within a few working days.</p>
  </div>
</section>
""")

# ==================================================================
# 404
# ==================================================================
PAGES_LEGAL["404.html"] = dict(
  title="Page Not Found | Mankind First Foundation",
  desc="The page you were looking for could not be found. Explore our programs, story or donate pages instead.",
  body="""
<section class="section" style="min-height:52vh;display:flex;align-items:center">
  <div class="container center narrow">
    <div class="card-icon orange mx-auto" style="width:84px;height:84px;margin-bottom:1.4rem">{{ICON:alert}}</div>
    <h1 style="font-size:clamp(3rem,8vw,4.6rem);margin-bottom:.2em">404</h1>
    <p class="lead">This page seems to have wandered off. Even the best of us lose our way sometimes — here&rsquo;s how to get back on track.</p>
    <div class="btn-row mt-2" style="justify-content:center">
      <a class="btn btn-primary" href="index.html">{{ICON:home}} Go Home</a>
      <a class="btn btn-ghost" href="programs.html">See Our Programs</a>
      <a class="btn btn-accent" href="donate.html">{{ICON:heart}} Donate</a>
    </div>
  </div>
</section>
""")

# ==================================================================
# THANK YOU (form service redirect target)
# ==================================================================
PAGES_LEGAL["thank-you.html"] = dict(
  title="Thank You | Mankind First Foundation",
  desc="Thank you for reaching out to Mankind First Foundation — we have received your message and will reply soon.",
  body="""
<section class="section" style="min-height:52vh;display:flex;align-items:center">
  <div class="container center narrow">
    <div class="card-icon green mx-auto" style="width:84px;height:84px;margin-bottom:1.4rem">{{ICON:check}}</div>
    <h1>Thank you.</h1>
    <p class="lead">Your message has been received. A real person will read it and reply as soon as we can — usually within a few working days.</p>
    <div class="btn-row mt-2" style="justify-content:center">
      <a class="btn btn-primary" href="index.html">Back to Home</a>
      <a class="btn btn-ghost" href="programs.html">See Our Work</a>
    </div>
  </div>
</section>
""")
