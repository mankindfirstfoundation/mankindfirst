#!/usr/bin/env python3
"""Builds preview.html — a single self-contained file with all site pages,
images and fonts embedded as data URIs, plus a tiny hash router so the
whole website can be clicked through in any viewer or offline."""
import base64, os, re, io
from PIL import Image

SITE = "mankind-first-foundation"
ROOT = os.path.join(os.path.dirname(__file__), "..")
SITE_DIR = os.path.join(ROOT, SITE)

PREVIEW_PAGES = ["index.html","about.html","mission.html","programs.html","stories.html",
                 "get-involved.html","donate.html","fundraising.html","transparency.html",
                 "news.html","contact.html","faq.html","privacy.html","terms.html","accessibility.html"]

def data_uri(path, max_w=860, q=66):
    """Data URI with photos downscaled for a light single-file preview."""
    ext = os.path.splitext(path)[1].lower()
    if ext == ".woff2":
        with open(path,"rb") as f:
            return "data:font/woff2;base64," + base64.b64encode(f.read()).decode()
    if ext in (".jpg", ".jpeg"):
        im = Image.open(path).convert("RGB")
        if im.width > max_w:
            im = im.resize((max_w, int(im.height * max_w / im.width)), Image.LANCZOS)
        buf = io.BytesIO()
        im.save(buf, "JPEG", quality=q, optimize=True, progressive=True)
        return "data:image/jpeg;base64," + base64.b64encode(buf.getvalue()).decode()
    if ext == ".png":
        with open(path,"rb") as f:
            return "data:image/png;base64," + base64.b64encode(f.read()).decode()
    raise ValueError(ext)

pages_html = {}
for f in PREVIEW_PAGES:
    html = open(os.path.join(SITE_DIR,f), encoding="utf-8").read()
    pages_html[f.replace(".html","")] = re.search(r"<main id=\"main\">\n?(.*?)\n</main>", html, re.S).group(1)

css = open(os.path.join(SITE_DIR,"css/styles.css"), encoding="utf-8").read()
js  = open(os.path.join(SITE_DIR,"js/main.js"), encoding="utf-8").read()
for w in [500,700,800]:
    css = css.replace(f"../assets/fonts/manrope-{w}.woff2", data_uri(os.path.join(SITE_DIR,f"assets/fonts/manrope-{w}.woff2")))

img_keys = {}  # key -> data URI (each image embedded exactly once)
def rewrite_assets(html):
    def sub(m):
        attr, url = m.group(1), m.group(2)
        if url.startswith(("data:","http")): return m.group(0)
        key = None
        for k, u in KEY_BY_URL.items():
            if u == url: key = k
        if key is None:
            key = "i" + str(len(KEY_BY_URL) + 1)
            KEY_BY_URL[key] = url
            img_keys[key] = data_uri(os.path.join(SITE_DIR, url))
        if attr == "src":
            return f'src="" data-imgkey="{key}"'
        return 'href="#"'
    return re.sub(r'(src|href)="(assets/[^"]+)"', sub, html)

KEY_BY_URL = {}

def rewrite_links(html):
    def sub(m):
        base, frag = m.group(1)[:-5], m.group(2) or ""
        if base in pages_html:
            target = "home" if base == "index" else base
            return f'href="#/{target}{frag}"'
        return m.group(0)
    return re.sub(r'href="([a-z0-9\-]+\.html)(#[a-z\-]+)?"', sub, html)

shell_pages = "\n".join(
    f'<div class="pv-page" data-page="{"home" if s=="index" else s}">{rewrite_links(rewrite_assets(b))}</div>'
    for s, b in pages_html.items())

NAV = [("home","Home"),("about","About"),("programs","Programs"),("stories","Impact"),
       ("get-involved","Get Involved"),("news","News"),("contact","Contact")]
nav_items = "".join(f'<li><a href="#/{s}" data-nav="{s}">{label}</a></li>' for s,label in NAV)
emblem = data_uri(os.path.join(SITE_DIR,"assets/images/emblem-192.png"))
og = data_uri(os.path.join(SITE_DIR,"assets/images/og-image.jpg"))

TEMPLATE = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Mankind First Foundation — Full Website Preview</title>
<meta name="description" content="Interactive single-file preview of the complete Mankind First Foundation website.">
<meta property="og:title" content="Mankind First Foundation — Website Preview">
<meta property="og:image" content="__OG__">
<meta name="theme-color" content="#0B2545">
<link rel="icon" type="image/png" href="__EMBLEM__">
<style>
__CSS__
.pv-note{background:#0B2545;color:#CDE2F2;text-align:center;font-size:.85rem;padding:.55rem 1rem}
.pv-note strong{color:#fff}
.pv-page{display:none}
.pv-page.active{display:block}
.primary-nav a[data-nav].active-nav{background:var(--sky-100);color:var(--blue-700)}
</style>
</head>
<body>
<div class="pv-note">Single-file preview of the complete website. The deployable multi-page version lives in the <strong>mankind-first-foundation/</strong> folder.</div>
<a class="skip-link" href="#main">Skip to main content</a>
<header class="site-header">
  <div class="container header-inner">
    <a class="brand" href="#/home" aria-label="Mankind First Foundation — home">
      <img src="__EMBLEM__" alt="" width="46" height="46">
      <span class="brand-text"><span class="brand-name">Mankind <b>First</b></span><span class="brand-sub">Foundation</span></span>
    </a>
    <nav class="primary-nav" aria-label="Primary navigation">
      <button class="nav-toggle" aria-expanded="false" aria-controls="nav-menu">Menu</button>
      <ul id="nav-menu">__NAV__
        <li><a class="btn btn-accent" href="#/donate">Donate</a></li>
      </ul>
    </nav>
  </div>
</header>
<main id="main">
__PAGES__
</main>
<footer class="site-footer">
  <div class="container">
    <div class="footer-grid">
      <div class="footer-about">
        <a class="brand" href="#/home" aria-label="Mankind First Foundation — home">
          <img src="__EMBLEM__" alt="" width="46" height="46">
          <span class="brand-text"><span class="brand-name">Mankind <b>First</b></span><span class="brand-sub">Foundation</span></span>
        </a>
        <p>Putting mankind first — supporting dignity, opportunity and practical help for people and communities facing hardship.</p>
        <p class="footer-note">A humanitarian foundation in its founding stage. Program and registration details are published on the Transparency page as they are confirmed.</p>
      </div>
      <div class="footer-col"><h4>Explore</h4><ul>
        <li><a href="#/about">About Us</a></li><li><a href="#/mission">Mission &amp; Values</a></li>
        <li><a href="#/programs">What We Do</a></li><li><a href="#/stories">Impact &amp; Stories</a></li>
        <li><a href="#/news">News &amp; Updates</a></li><li><a href="#/faq">FAQ</a></li></ul></div>
      <div class="footer-col"><h4>Get Involved</h4><ul>
        <li><a href="#/donate">Donate</a></li><li><a href="#/get-involved">Volunteer</a></li>
        <li><a href="#/fundraising">Fundraising</a></li><li><a href="#/get-involved#partner">Partner With Us</a></li>
        <li><a href="#/contact">Contact</a></li></ul></div>
      <div class="footer-col"><h4>Trust</h4><ul>
        <li><a href="#/transparency">Transparency &amp; Accountability</a></li><li><a href="#/privacy">Privacy Policy</a></li>
        <li><a href="#/terms">Terms &amp; Disclaimer</a></li><li><a href="#/accessibility">Accessibility Statement</a></li></ul>
        <p class="footer-note" style="margin-top:1.2rem">Social media links will be added here once the foundation&rsquo;s official accounts are live.</p></div>
    </div>
    <div class="footer-bottom">
      <span>&copy; <span data-year>2026</span> Mankind First Foundation. All rights reserved.</span>
      <span class="made">Built with care for people.</span>
    </div>
  </div>
</footer>
<script>
__JS__
/* ---------- preview router ---------- */
(function(){
  var pages = document.querySelectorAll(".pv-page");
  function show(slug){
    if(!slug) slug = "home";
    var found = false;
    pages.forEach(function(p){ var on = p.getAttribute("data-page") === slug; p.classList.toggle("active", on); if(on) found = true; });
    if(!found){ pages.forEach(function(p){ p.classList.toggle("active", p.getAttribute("data-page") === "home"); }); slug = "home"; }
    document.querySelectorAll("[data-nav]").forEach(function(a){ a.classList.toggle("active-nav", a.getAttribute("href") === "#/" + slug); });
    var openNav = document.querySelector(".primary-nav.open");
    if(openNav){ openNav.classList.remove("open"); var t = document.querySelector(".nav-toggle"); t.setAttribute("aria-expanded","false"); t.textContent = "Menu"; }
    window.scrollTo(0,0);
    var h1 = document.querySelector(".pv-page.active h1");
    document.title = (h1 ? h1.textContent.trim().replace(/\\s+/g," ") : "Mankind First Foundation") + " | Mankind First Foundation";
  }
  function route(){
    var parts = location.hash.replace(/^#\\/?/, "").split("#");
    show(parts[0]);
    if(parts[1]){
      var el = document.querySelector('.pv-page.active #' + parts[1]);
      if(el){ setTimeout(function(){ el.scrollIntoView({behavior:"smooth"}); }, 60); }
    }
  }
  window.addEventListener("hashchange", route);
  route();
})();
</script>
</body>
</html>"""

import json
img_map_js = "var IMG=" + json.dumps(img_keys) + ";" + """
if("contentLoading" in document){} 
document.addEventListener("DOMContentLoaded", function(){
  document.querySelectorAll("[data-imgkey]").forEach(function(el){
    el.src = IMG[el.getAttribute("data-imgkey")] || "";
  });
});"""
loader = img_map_js

out = (TEMPLATE.replace("__CSS__", css)
               .replace("__JS__", js + "\n" + loader)
               .replace("__NAV__", nav_items)
               .replace("__PAGES__", shell_pages)
               .replace("__EMBLEM__", emblem)
               .replace("__OG__", og))

out_path = os.path.join(ROOT, "preview.html")
open(out_path, "w", encoding="utf-8").write(out)
print(f"preview.html written: {os.path.getsize(out_path)//1024} KB, {len(PREVIEW_PAGES)} pages embedded")
