#!/usr/bin/env python3
"""Mankind First Foundation — static site generator.
Builds the multi-page website from shared templates so every page
stays visually consistent and the SEO scaffolding is identical.

Run:  python3 site-build/build.py
Output: /mankind-first-foundation/*.html
"""
import os, sys

sys.path.insert(0, os.path.dirname(__file__))
from pages_core import PAGES_CORE
from pages_more import PAGES_MORE
from pages_legal import PAGES_LEGAL

# ------------------------------------------------------------------
# EDIT ME: the live domain once hosting is chosen (used in canonical
# URLs, Open Graph tags and sitemap.xml).
SITE_URL = "https://www.mankindfirstfoundation.org"
SITE_NAME = "Mankind First Foundation"
TAGLINE = "Compassion in action. Communities supported. Human dignity respected."
FOUNDER_NOTE = "Founding stage"
YEAR_TOKEN = "{YEAR}"
# ------------------------------------------------------------------

ICONS = {
  "arrow":   '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12h14M12 5l7 7-7 7"/></svg>',
  "check":   '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="20 6 9 17 4 12"/></svg>',
  "heart":   '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg>',
  "book":    '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"/><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"/></svg>',
  "health":  '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="10"/><path d="M12 8v8M8 12h8"/></svg>',
  "drop":    '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 2.69l5.66 5.66a8 8 0 1 1-11.31 0z"/></svg>',
  "users":   '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>',
  "shield":  '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>',
  "alert":   '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>',
  "globe":   '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg>',
  "mail":    '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>',
  "gift":    '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="20 12 20 22 4 22 4 12"/><rect x="2" y="7" width="20" height="5"/><line x1="12" y1="22" x2="12" y2="7"/><path d="M12 7H7.5a2.5 2.5 0 0 1 0-5C11 2 12 7 12 7z"/><path d="M12 7h4.5a2.5 2.5 0 0 0 0-5C13 2 12 7 12 7z"/></svg>',
  "trend":   '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="23 6 13.5 15.5 8.5 10.5 1 18"/><polyline points="17 6 23 6 23 12"/></svg>',
  "zap":     '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>',
  "home":    '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>',
  "sun":     '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="5"/><path d="M12 1v2M12 21v2M4.22 4.22l1.42 1.42M18.36 18.36l1.42 1.42M1 12h2M21 12h2M4.22 19.78l1.42-1.42M18.36 5.64l1.42-1.42"/></svg>',
  "file":    '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg>',
  "message": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>',
  "qr":      '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" aria-hidden="true"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><path d="M14 14h3v3h-3zM20 14h1v1h-1zM17 17.5h1M14 20h1M17.5 20H21M20 17h1v1h-1z"/></svg>',
  "external":"<svg viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\"><path d=\"M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6\"/><polyline points=\"15 3 21 3 21 9\"/><line x1=\"10\" y1=\"14\" x2=\"21\" y2=\"3\"/></svg>",
  "seedling":'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 22v-9"/><path d="M12 13C12 8 8 5 3 5c0 5 4 8 9 8z"/><path d="M12 13c0-5 4-8 9-8 0 5-4 8-9 8z"/></svg>',
  "plus":    '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" aria-hidden="true"><path d="M12 5v14M5 12h14"/></svg>',
  "eye":     '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>',
}

EMBLEM = "assets/images/emblem-192.png"

def icon(name, cls=""):
    svg = ICONS[name]
    if cls:
        svg = svg.replace("<svg ", f'<svg class="{cls}" ', 1)
    return svg

NAV = [
    ("index.html", "Home"),
    ("about.html", "About"),
    ("programs.html", "Programs"),
    ("stories.html", "Impact"),
    ("get-involved.html", "Get Involved"),
    ("news.html", "News"),
    ("contact.html", "Contact"),
]

def header(active):
    items = []
    for href, label in NAV:
        cur = ' aria-current="page"' if href == active else ""
        items.append(f'<li><a href="{href}"{cur}>{label}</a></li>')
    nav_items = "".join(items)
    return f"""
<a class="skip-link" href="#main">Skip to main content</a>
<header class="site-header">
  <div class="container header-inner">
    <a class="brand" href="index.html" aria-label="{SITE_NAME} — home">
      <img src="{EMBLEM}" alt="" width="46" height="46">
      <span class="brand-text">
        <span class="brand-name">Mankind <b>First</b></span>
        <span class="brand-sub">Foundation</span>
      </span>
    </a>
    <nav class="primary-nav" aria-label="Primary navigation">
      <button class="nav-toggle" aria-expanded="false" aria-controls="nav-menu">Menu</button>
      <ul id="nav-menu">
        {nav_items}
        <li><a class="btn btn-accent" href="donate.html">{icon('heart')} Donate</a></li>
      </ul>
    </nav>
  </div>
</header>"""

def footer():
    return f"""
<footer class="site-footer">
  <div class="container">
    <div class="footer-grid">
      <div class="footer-about">
        <a class="brand" href="index.html" aria-label="{SITE_NAME} — home">
          <img src="{EMBLEM}" alt="" width="46" height="46">
          <span class="brand-text">
            <span class="brand-name">Mankind <b>First</b></span>
            <span class="brand-sub">Foundation</span>
          </span>
        </a>
        <p>Putting mankind first — supporting dignity, opportunity and practical help for people and communities facing hardship.</p>
        <p class="footer-note">Second Floor, Al-Hamd Plaza, Bosan Road, Multan, Punjab, Pakistan<br>info@mankindfirst.org · +92 61 458 0214</p>
      </div>
      <div class="footer-col">
        <h4>Explore</h4>
        <ul>
          <li><a href="about.html">About Us</a></li>
          <li><a href="mission.html">Mission &amp; Values</a></li>
          <li><a href="programs.html">What We Do</a></li>
          <li><a href="stories.html">Impact &amp; Stories</a></li>
          <li><a href="news.html">News &amp; Updates</a></li>
          <li><a href="faq.html">FAQ</a></li>
        </ul>
      </div>
      <div class="footer-col">
        <h4>Get Involved</h4>
        <ul>
          <li><a href="donate.html">Donate</a></li>
          <li><a href="get-involved.html">Volunteer</a></li>
          <li><a href="fundraising.html">Fundraising</a></li>
          <li><a href="get-involved.html#partner">Partner With Us</a></li>
          <li><a href="contact.html">Contact</a></li>
        </ul>
      </div>
      <div class="footer-col">
        <h4>Trust</h4>
        <ul>
          <li><a href="transparency.html">Transparency &amp; Accountability</a></li>
          <li><a href="privacy.html">Privacy Policy</a></li>
          <li><a href="terms.html">Terms &amp; Disclaimer</a></li>
          <li><a href="accessibility.html">Accessibility Statement</a></li>
        </ul>
        <p class="footer-note" style="margin-top:1.2rem">Social media links will be added here once the foundation&rsquo;s official accounts are live.</p>
      </div>
    </div>
    <div class="footer-bottom">
      <span>&copy; <span data-year>2026</span> {SITE_NAME}. All rights reserved.</span>
      <span class="made">{icon('heart')} Built with care for people.</span>
    </div>
  </div>
</footer>"""

ORG_JSONLD = f'''{{
  "@context": "https://schema.org",
  "@type": "NGO",
  "name": "{SITE_NAME}",
  "url": "{SITE_URL}/",
  "logo": "{SITE_URL}/assets/images/emblem-512.png",
  "description": "A humanitarian foundation putting mankind first — compassion in action, communities supported, human dignity respected.",
  "slogan": "Putting Mankind First."
}}'''

def page(slug, title, desc, body, json_ld=""):
    canon = f"{SITE_URL}/{slug}" if slug != "index.html" else f"{SITE_URL}/"
    ld = ORG_JSONLD if slug == "index.html" else json_ld
    ld_block = f'<script type="application/ld+json">{ld}</script>' if ld else ""
    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{title}</title>
<meta name="description" content="{desc}">
<link rel="canonical" href="{canon}">
<meta property="og:type" content="website">
<meta property="og:site_name" content="{SITE_NAME}">
<meta property="og:title" content="{title}">
<meta property="og:description" content="{desc}">
<meta property="og:url" content="{canon}">
<meta property="og:image" content="{SITE_URL}/assets/images/og-image.jpg">
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="{title}">
<meta name="twitter:description" content="{desc}">
<meta name="twitter:image" content="{SITE_URL}/assets/images/og-image.jpg">
<meta name="theme-color" content="#0B2545">
<link rel="icon" type="image/png" sizes="64x64" href="assets/images/favicon-64.png">
<link rel="icon" type="image/png" sizes="192x192" href="assets/images/emblem-192.png">
<link rel="apple-touch-icon" href="assets/images/apple-touch-icon.png">
<link rel="stylesheet" href="css/styles.css">
{ld_block}
</head>
<body>
{header(slug)}
<main id="main">
{body}
</main>
{footer()}
<script src="js/main.js" defer></script>
</body>
</html>"""

def breadcrumbs(label):
    return f"""<nav class="breadcrumbs" aria-label="Breadcrumb">
<a href="index.html">Home</a><span aria-hidden="true">/</span><span aria-current="page">{label}</span>
</nav>"""

def write_all(outdir):
    os.makedirs(outdir, exist_ok=True)
    all_pages = {}
    all_pages.update(PAGES_CORE)
    all_pages.update(PAGES_MORE)
    all_pages.update(PAGES_LEGAL)
    for slug, spec in all_pages.items():
        html = page(slug, spec["title"], spec["desc"], spec["body"], spec.get("json_ld", ""))
        # breadcrumb token -> real breadcrumb nav (label from page title)
        crumb_label = spec.get("crumb", spec["title"].split("|")[0].strip())
        html = html.replace("{{CRUMB}}", breadcrumbs(crumb_label))
        # replace inline icon tokens used by page content: {{ICON:name}} / {{ICON:name|class}}
        import re
        def _icon_sub(m):
            name, _, cls = m.group(1).partition("|")
            return icon(name, cls)
        html = re.sub(r"\{\{ICON:([a-z]+)(?:\|([a-z\-]+))?\}\}", _icon_sub, html)
        path = os.path.join(outdir, slug)
        with open(path, "w", encoding="utf-8") as f:
            f.write(html)
        print(f"  wrote {slug:22s} {len(html)//1024} KB")
    print(f"\n{len(all_pages)} pages written to {outdir}/")

if __name__ == "__main__":
    write_all(os.path.join(os.path.dirname(__file__), "..", "mankind-first-foundation"))
