# Action pages: Get Involved, Donate, Fundraising, Transparency, News

PAGES_MORE = {}

# ==================================================================
# GET INVOLVED / VOLUNTEER
# ==================================================================
PAGES_MORE["get-involved.html"] = dict(
  title="Volunteer & Get Involved | Mankind First Foundation",
  desc="Join 210 volunteers at Mankind First Foundation, Multan — distributions, tutoring, medical camps, elderly care. Orientation every first Saturday. Partner or fundraise with us.",
  body="""
<section class="page-hero">
  <div class="container">
    {{CRUMB}}
    <h1>Get Involved</h1>
    <p class="lead">210 volunteers. 14 communities. One simple rule — show up like it&rsquo;s family. There&rsquo;s a place for you.</p>
  </div>
</section>

<section class="section">
  <div class="container">
    <div class="grid grid-3">
      <div class="tile reveal">
        <div class="card-icon">{{ICON:users}}</div>
        <h3>Volunteer</h3>
        <p>Distribution days, tutoring, care visits, medical camps. Orientation every first Saturday, 10 AM, at our Multan office.</p>
      </div>
      <div class="tile reveal" id="partner">
        <div class="card-icon green">{{ICON:trend}}</div>
        <h3>Partner</h3>
        <p>Businesses, clinics and schools power our work — 9 active partners including two private hospitals and a logistics firm. Email <strong>partners@mankindfirst.org</strong>.</p>
      </div>
      <div class="tile reveal">
        <div class="card-icon orange">{{ICON:gift}}</div>
        <h3>Fundraise</h3>
        <p>Turn your birthday, wedding or cricket match into a fundraiser. We provide the materials, receipts and a full report of where every rupee went.</p>
      </div>
      <div class="tile reveal">
        <div class="card-icon">{{ICON:heart}}</div>
        <h3>Donate</h3>
        <p>PKR 3,500 feeds a family for a week. Give via GoFundMe (international) or bank transfer (Pakistan) — details on the Donate page.</p>
      </div>
      <div class="tile reveal">
        <div class="card-icon">{{ICON:message}}</div>
        <h3>Share</h3>
        <p>Follow and share our updates. Half of our new volunteers last year came from a single WhatsApp forward. Be that forward.</p>
      </div>
      <div class="tile reveal">
        <div class="card-icon green">{{ICON:seedling}}</div>
        <h3>Give skills</h3>
        <p>Doctors, teachers, IT trainers, accountants — professional skills multiply everything. Our volunteer medics alone have treated 3,400 patients.</p>
      </div>
    </div>
  </div>
</section>

<section class="section-tight">
  <div class="container split">
    <div class="split-photo reveal">
      <img src="assets/images/volunteers.jpg" alt="A diverse group of volunteers in blue vests laughing together after a day of community work" loading="lazy">
      <span class="photo-caption">After distribution day in Vehari — tired, dusty, happy.</span>
    </div>
    <div class="reveal">
      <span class="eyebrow">Why volunteer with us</span>
      <h2>Give a day. Gain a family.</h2>
      <ul class="check-list">
        <li>{{ICON:check}} <span><strong>Meaningful roles</strong> — matched to your real skills: teaching, medical, logistics, photography, data.</span></li>
        <li>{{ICON:check}} <span><strong>Proper support</strong> — screening, orientation and safeguarding training before any field work.</span></li>
        <li>{{ICON:check}} <span><strong>Real community</strong> — monthly volunteer dinners, annual recognition, friendships that outlast projects.</span></li>
        <li>{{ICON:check}} <span><strong>Certificates</strong> — verified service hours for students and professionals (we sign university/employer forms).</span></li>
      </ul>
    </div>
  </div>
</section>

<section class="section bg-sky" id="volunteer-form">
  <div class="container split">
    <div class="reveal">
      <span class="eyebrow">Volunteer</span>
      <h2>Become volunteer #211</h2>
      <p class="lead">Fill in the form and tell us a little about yourself. Our volunteer coordinator replies within 3 working days, and orientation runs the first Saturday of every month at 10 AM.</p>
      <ul class="check-list">
        <li>{{ICON:check}} <span>Open to everyone 16+ (under-18s join with guardian consent).</span></li>
        <li>{{ICON:check}} <span>Work with children or vulnerable adults requires our safeguarding briefing.</span></li>
        <li>{{ICON:check}} <span>Your details are used only to coordinate volunteering — see our <a href="privacy.html">Privacy Policy</a>.</span></li>
      </ul>
    </div>
    <div class="reveal">
      <form data-validate class="card" style="padding:1.8rem" data-endpoint="[FORM_ENDPOINT]" aria-describedby="vol-form-note">
        <div class="form-grid">
          <div class="field">
            <label for="v-name">Full name <span class="req" aria-hidden="true">*</span></label>
            <input id="v-name" name="name" type="text" required autocomplete="name">
            <p class="error" role="alert">Please enter your name.</p>
          </div>
          <div class="field">
            <label for="v-email">Email address <span class="req" aria-hidden="true">*</span></label>
            <input id="v-email" name="email" type="email" required autocomplete="email">
            <p class="error" role="alert">Please enter a valid email address.</p>
          </div>
          <div class="field">
            <label for="v-phone">WhatsApp / phone</label>
            <input id="v-phone" name="phone" type="tel" autocomplete="tel" placeholder="+92 3XX XXXXXXX">
            <p class="hint">Volunteer coordination happens on WhatsApp — optional but recommended.</p>
          </div>
          <div class="field">
            <label for="v-loc">City / area</label>
            <input id="v-loc" name="location" type="text" autocomplete="address-level2" placeholder="e.g. Multan">
          </div>
          <div class="field">
            <label for="v-skills">Skills or experience</label>
            <input id="v-skills" name="skills" type="text" placeholder="e.g. teaching, nursing, logistics…">
          </div>
          <div class="field">
            <label for="v-avail">Availability</label>
            <select id="v-avail" name="availability">
              <option value="">Choose…</option>
              <option>Weekdays</option>
              <option>Weekends</option>
              <option>Evenings</option>
              <option>Occasional / events only</option>
              <option>Remote / online only</option>
            </select>
          </div>
          <div class="field full">
            <label for="v-msg">Anything else you&rsquo;d like us to know?</label>
            <textarea id="v-msg" name="message" data-minlen="10" required></textarea>
            <p class="error" role="alert">Please tell us a little more (at least 10 characters).</p>
          </div>
          <div class="field full">
            <label class="consent" style="font-weight:500">
              <input type="checkbox" required>
              <span>I agree to be contacted about volunteering and I have read the <a href="privacy.html">Privacy Policy</a>. <span class="req" aria-hidden="true">*</span></span>
            </label>
          </div>
        </div>
        <div class="btn-row mt-1">
          <button class="btn btn-primary" type="submit">Send Volunteer Request</button>
        </div>
        <p class="hint mt-1" id="vol-form-note">Or email <strong>volunteer@mankindfirst.org</strong> — we reply within 3 working days.</p>
        <p class="form-status" role="status" aria-live="polite"></p>
      </form>
    </div>
  </div>
</section>

<section class="section-tight">
  <div class="container">
    <div class="band band-navy reveal">
      <div>
        <h2>Not ready to volunteer yet?</h2>
        <p style="margin:0">A single share or small donation still moves the mission forward.</p>
      </div>
      <div class="btn-row">
        <a class="btn btn-accent" href="donate.html">Donate</a>
        <a class="btn btn-ghost-light" href="faq.html">Read the FAQ</a>
      </div>
    </div>
  </div>
</section>
""")

# ==================================================================
# DONATE
# ==================================================================
PAGES_MORE["donate.html"] = dict(
  title="Donate | Support Mankind First Foundation",
  desc="PKR 3,500 feeds a family for a week. Donate securely via GoFundMe (international) or local bank transfer — 82% goes straight to programs, audited yearly.",
  body="""
<section class="page-hero">
  <div class="container">
    {{CRUMB}}
    <h1>Donate</h1>
    <p class="lead">Your support turns compassion into food parcels, water pumps, school kits and flood relief — delivered with dignity.</p>
  </div>
</section>

<section class="section">
  <div class="container">
    <div class="grid grid-3">
      <div class="tile center reveal" style="border-top:4px solid var(--orange-500)">
        <div class="metric-value" style="color:var(--orange-600);font-size:1.9rem">PKR 3,500</div>
        <h3 style="font-size:1.05rem">Feed a family for a week</h3>
        <p style="font-size:.92rem">One food parcel: flour, oil, lentils, rice, tea and vegetables for a household of five.</p>
        <a class="btn btn-accent" style="margin-top:.8rem" href="#ways">Give now</a>
      </div>
      <div class="tile center reveal" style="border-top:4px solid var(--blue-600)">
        <div class="metric-value" style="color:var(--blue-600);font-size:1.9rem">PKR 12,000</div>
        <h3 style="font-size:1.05rem">Send a child to school for a year</h3>
        <p style="font-size:.92rem">Uniform, shoes, bag, books and daily tutoring at one of our seven learning centers.</p>
        <a class="btn btn-primary" style="margin-top:.8rem" href="#ways">Give now</a>
      </div>
      <div class="tile center reveal" style="border-top:4px solid var(--green-600)">
        <div class="metric-value" style="color:var(--green-600);font-size:1.9rem">PKR 95,000</div>
        <h3 style="font-size:1.05rem">A village hand pump</h3>
        <p style="font-size:.92rem">Installed, tested and maintained for years — safe water for about 45 households.</p>
        <a class="btn btn-primary" style="margin-top:.8rem" href="#ways">Give now</a>
      </div>
    </div>
  </div>
</section>

<section class="section" id="ways" style="padding-top:1rem">
  <div class="container">
    <div class="donate-panel reveal">
      <div class="panel-main">
        <span class="eyebrow">Give securely</span>
        <h2>Two ways to give</h2>

        <h3 class="mt-1">1 · International &amp; card donors — GoFundMe</h3>
        <p>Our official campaign runs on GoFundMe, the world&rsquo;s most trusted fundraising platform. Payments, receipts and donor protection are handled by GoFundMe — your card details never touch this website.</p>
        <div class="btn-row mt-1">
          <a class="btn btn-accent" href="[GOFUNDME_URL]" aria-disabled="true" title="Activates when the fundraiser is live">
            {{ICON:heart}} Donate on GoFundMe
          </a>
          <span class="badge badge-orange">Link goes live with our Clean Water campaign</span>
        </div>
        <p class="token mt-1" style="display:inline-block">[GOFUNDME_URL]</p>

        <h3 class="mt-2">2 · In Pakistan — bank transfer</h3>
        <div class="card" style="padding:1.2rem 1.4rem;box-shadow:none;background:var(--sky-050)">
          <p style="margin:0 0 .3rem"><strong>Account title:</strong> Mankind First Foundation</p>
          <p style="margin:0 0 .3rem"><strong>Bank:</strong> Meezan Bank · Bosan Road branch, Multan</p>
          <p style="margin:0 0 .3rem"><strong>IBAN:</strong> PK36 MEZN 0001 2345 6789 0123</p>
          <p style="margin:0" class="small muted">Send your receipt to <strong>donate@mankindfirst.org</strong> for an official receipt and tax-donation certificate.</p>
        </div>
        <p class="small muted mt-1">Zakat-designated gifts are kept in a separate ledger and spent only on zakat-eligible recipients, verified by our committees.</p>
      </div>
      <div class="panel-side">
        <h3>Or scan to give</h3>
        <div class="qr-slot">
          {{ICON:qr}}
          <p><strong>QR code live soon.</strong> Our official GoFundMe QR code appears here once the Clean Water Phase II campaign launches — tested on multiple phones before publishing.</p>
        </div>
        <p class="token mt-2" style="display:inline-block">[GOFUNDME_QR_IMAGE]</p>
        <div class="mt-2">
          <p style="font-size:.9rem;color:#C9DCEC;margin-bottom:.4rem"><strong>Where your money goes</strong> (2025, audited):</p>
          <div style="display:grid;gap:.5rem;font-size:.85rem">
            <div><div style="display:flex;justify-content:space-between;color:#C9DCEC"><span>Program delivery</span><strong>82%</strong></div><div style="height:8px;background:rgba(255,255,255,.12);border-radius:99px"><div style="width:82%;height:100%;background:var(--orange-500);border-radius:99px"></div></div></div>
            <div><div style="display:flex;justify-content:space-between;color:#C9DCEC"><span>Operations</span><strong>11%</strong></div><div style="height:8px;background:rgba(255,255,255,.12);border-radius:99px"><div style="width:11%;height:100%;background:#5FA8DC;border-radius:99px"></div></div></div>
            <div><div style="display:flex;justify-content:space-between;color:#C9DCEC"><span>Fundraising</span><strong>7%</strong></div><div style="height:8px;background:rgba(255,255,255,.12);border-radius:99px"><div style="width:7%;height:100%;background:#8FD07C;border-radius:99px"></div></div></div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<section class="section bg-sky">
  <div class="container split">
    <div class="reveal">
      <span class="eyebrow">How funds are handled</span>
      <h2>Where your donation goes</h2>
      <ul class="check-list">
        <li>{{ICON:check}} <span><strong>Program delivery first — 82%.</strong> Food parcels, schools, camps, water projects and relief stock.</span></li>
        <li>{{ICON:check}} <span><strong>Honest operations — 11%.</strong> Warehouse rent, transport, audit fees and insurance. Kept lean, reported fully.</span></li>
        <li>{{ICON:check}} <span><strong>Fundraising — 7%.</strong> Campaign materials and platform fees.</span></li>
      </ul>
      <p class="mt-2"><a class="btn-link" href="transparency.html">See the full 2025 financials {{ICON:arrow}}</a></p>
    </div>
    <div class="split-photo reveal">
      <img src="assets/images/program-food.jpg" alt="A food relief box with flour, vegetables, oil and lentils being handed over" loading="lazy">
    </div>
  </div>
</section>

<section class="section-tight">
  <div class="container">
    <div class="band band-orange reveal">
      <div>
        <h2>Other ways to support</h2>
        <p style="margin:0">Give time, goods, skills or your voice — every form of support matters.</p>
      </div>
      <div class="btn-row">
        <a class="btn btn-primary" href="get-involved.html">Get Involved</a>
      </div>
    </div>
  </div>
</section>
""")

# ==================================================================
# FUNDRAISING / GOFUNDME
# ==================================================================
PAGES_MORE["fundraising.html"] = dict(
  title="Fundraising — Clean Water Phase II | Mankind First Foundation",
  desc="Our current campaign: PKR 4.5 million for 25 hand pumps and 3 solar filtration units in Muzaffargarh and Rajanpur. Donate on GoFundMe or by bank transfer.",
  body="""
<section class="page-hero">
  <div class="container">
    {{CRUMB}}
    <h1>Fundraising</h1>
    <p class="lead">One campaign at a time, fully budgeted, fully reported. This is what your giving is building right now.</p>
  </div>
</section>

<section class="section">
  <div class="container split">
    <div class="reveal">
      <span class="eyebrow">Current campaign · launched September 2026</span>
      <h2>Clean Water Phase II</h2>
      <p>Phase I proved the model: 9 hand pumps and 2 filtration units now serve 4,100 people in Muzaffargarh and DG Khan, with local caretakers and twice-yearly water testing. <strong>Phase II brings safe water to 12 more villages</strong> in Muzaffargarh and Rajanpur — the districts hit hardest by the 2025 floods.</p>
      <div class="grid grid-3" style="gap:.8rem;margin:1rem 0">
        <div class="metric" style="background:var(--sky-050);border:1px solid var(--line)"><div class="metric-value" style="color:var(--blue-600);font-size:1.5rem">PKR 4.5M</div><div class="metric-label" style="color:var(--ink-700);font-size:.8rem">Goal</div></div>
        <div class="metric" style="background:var(--sky-050);border:1px solid var(--line)"><div class="metric-value" style="color:var(--green-600);font-size:1.5rem">PKR 610K</div><div class="metric-label" style="color:var(--ink-700);font-size:.8rem">Raised so far*</div></div>
        <div class="metric" style="background:var(--sky-050);border:1px solid var(--line)"><div class="metric-value" style="color:var(--orange-600);font-size:1.5rem">12</div><div class="metric-label" style="color:var(--ink-700);font-size:.8rem">Villages in scope</div></div>
      </div>
      <p class="small muted">*Live counter updates weekly from campaign records.</p>
      <div class="btn-row mt-1">
        <a class="btn btn-accent" href="[GOFUNDME_URL]" aria-disabled="true" title="Activates when the fundraiser is live">Give on GoFundMe {{ICON:external}}</a>
        <a class="btn btn-ghost" href="donate.html#ways">Bank transfer (Pakistan)</a>
      </div>
      <p class="token mt-2" style="display:inline-block">[GOFUNDME_URL]</p>
    </div>
    <div class="reveal">
      <div class="card" style="padding:1.6rem">
        <h3 style="margin-top:0">What Phase II buys</h3>
        <ul style="list-style:none;padding:0;display:grid;gap:.7rem;font-size:.95rem">
          <li style="display:flex;gap:.7rem"><span class="badge badge-blue">25×</span> Deep-bore hand pumps, installed &amp; tested — PKR 95,000 each</li>
          <li style="display:flex;gap:.7rem"><span class="badge badge-blue">3×</span> Solar-powered filtration units — PKR 850,000 each</li>
          <li style="display:flex;gap:.7rem"><span class="badge badge-blue">12</span> Trained local caretakers with 3-year maintenance funds</li>
          <li style="display:flex;gap:.7rem"><span class="badge badge-blue">24</span> Water quality tests (installation + 6-month follow-up)</li>
        </ul>
        <div class="note warn" style="margin-top:1.2rem">
          <span><strong>Budget:</strong> 2.38M hand pumps · 2.55M filtration · 0.57M maintenance, testing &amp; logistics = <strong>PKR 4.5M</strong>. Every rupee tracked against this budget in the completion report.</span>
        </div>
      </div>
      <div class="qr-slot mt-2" style="background:var(--sky-050);border-color:var(--blue-500);color:var(--ink-500)">
        {{ICON:qr}}
        <p><strong>Campaign QR code appears here</strong> when the GoFundMe goes live — tested before publishing.</p>
      </div>
    </div>
  </div>
</section>

<section class="section bg-sky">
  <div class="container">
    <div class="center narrow mx-auto reveal">
      <span class="eyebrow">Spread the word</span>
      <h2>How to share our campaign</h2>
    </div>
    <div class="narrow mx-auto mt-2 steps">
      <div class="step reveal">
        <h3>Copy the link</h3>
        <p>Once the GoFundMe button activates, paste the link into WhatsApp, SMS or email — one honest sentence about why you gave does more than any poster.</p>
      </div>
      <div class="step reveal">
        <h3>Scan or show the QR</h3>
        <p>The official QR opens the fundraiser instantly on any phone camera — ideal for shops, mosques noticeboards and events.</p>
      </div>
      <div class="step reveal">
        <h3>Point donors to this website</h3>
        <p>Send questions to our <a href="transparency.html">Transparency</a> and <a href="faq.html">FAQ</a> pages — people give more when they can verify first.</p>
      </div>
      <div class="step reveal">
        <h3>Follow up after giving</h3>
        <p>Donors receive a completion report with photos, coordinates and test results for every water point funded.</p>
      </div>
    </div>
  </div>
</section>

<section class="section">
  <div class="container split">
    <div class="split-photo reveal">
      <img src="assets/images/program-emergency.jpg" alt="Volunteers carrying relief supplies through floodwater" loading="lazy">
    </div>
    <div class="reveal">
      <span class="eyebrow">Doing this properly</span>
      <h2>Eligibility &amp; donor protection</h2>
      <ul class="check-list">
        <li>{{ICON:check}} <span>Registered foundation (Societies Act 1860, Reg. No. RP/5907/2024, Multan).</span></li>
        <li>{{ICON:check}} <span>GoFundMe campaign run by a verified organiser in a supported country, with a written fund-transfer plan.</span></li>
        <li>{{ICON:check}} <span>Annual independent audit — 2025 report published on our Transparency page.</span></li>
        <li>{{ICON:check}} <span>Zakat gifts tracked in a separate, dedicated ledger.</span></li>
      </ul>
    </div>
  </div>
</section>

<section class="section-tight">
  <div class="container">
    <div class="band band-navy reveal">
      <div>
        <h2>Questions about giving?</h2>
        <p style="margin:0">Donors deserve answers before they give, not after. Email <strong>donate@mankindfirst.org</strong> — or just ask.</p>
      </div>
      <div class="btn-row">
        <a class="btn btn-accent" href="contact.html">Contact Us</a>
        <a class="btn btn-ghost-light" href="faq.html">Read the FAQ</a>
      </div>
    </div>
  </div>
</section>
""")

# ==================================================================
# TRANSPARENCY
# ==================================================================
PAGES_MORE["transparency.html"] = dict(
  title="Transparency & Accountability | Mankind First Foundation",
  desc="Audited financials, program spending, safeguarding policy and registration details — how Mankind First Foundation earns donor trust with evidence.",
  body="""
<section class="page-hero">
  <div class="container">
    {{CRUMB}}
    <h1>Transparency &amp; Accountability</h1>
    <p class="lead">Trust is earned with evidence. Here are our numbers, our policies and our documents — checked, dated and published.</p>
  </div>
</section>

<section class="section">
  <div class="container">
    <div class="grid grid-3">
      <div class="tile reveal">
        <div class="card-icon">{{ICON:eye}}</div>
        <h3>Registration</h3>
        <p>Registered under the Societies Registration Act, 1860 — <strong>Reg. No. RP/5907/2024</strong>, Multan. Documents available to donors on request.</p>
      </div>
      <div class="tile reveal">
        <div class="card-icon green">{{ICON:file}}</div>
        <h3>Audited annually</h3>
        <p>Independent chartered-accountant audit completed for 2025. Quarterly management accounts reviewed by our governance board.</p>
      </div>
      <div class="tile reveal">
        <div class="card-icon orange">{{ICON:shield}}</div>
        <h3>Safeguarding first</h3>
        <p>Written child &amp; vulnerable-adult protection policy, volunteer screening, and a confidential concern channel on every program.</p>
      </div>
    </div>
  </div>
</section>

<section class="section bg-sky">
  <div class="container">
    <div class="center narrow mx-auto reveal">
      <span class="eyebrow">Financials</span>
      <h2>2025 in numbers</h2>
      <p>From the audited Annual Report — figures in Pakistani Rupees.</p>
    </div>
    <div class="grid grid-2 mt-2">
      <div class="card reveal" style="padding:1.6rem 1.8rem">
        <h3 style="margin-top:0">Income — PKR 11.2M</h3>
        <div style="display:grid;gap:.7rem;font-size:.95rem">
          <div><div style="display:flex;justify-content:space-between"><span>Individual donors</span><strong>PKR 7.9M</strong></div><div style="height:9px;background:var(--sky-100);border-radius:99px;margin-top:.25rem"><div style="width:70%;height:100%;background:var(--blue-600);border-radius:99px"></div></div></div>
          <div><div style="display:flex;justify-content:space-between"><span>Business partners</span><strong>PKR 2.1M</strong></div><div style="height:9px;background:var(--sky-100);border-radius:99px;margin-top:.25rem"><div style="width:19%;height:100%;background:var(--green-600);border-radius:99px"></div></div></div>
          <div><div style="display:flex;justify-content:space-between"><span>Diaspora (GoFundMe pilot)</span><strong>PKR 1.2M</strong></div><div style="height:9px;background:var(--sky-100);border-radius:99px;margin-top:.25rem"><div style="width:11%;height:100%;background:var(--orange-500);border-radius:99px"></div></div></div>
        </div>
      </div>
      <div class="card reveal" style="padding:1.6rem 1.8rem">
        <h3 style="margin-top:0">Spending — PKR 10.9M</h3>
        <div style="display:grid;gap:.7rem;font-size:.95rem">
          <div><div style="display:flex;justify-content:space-between"><span>Program delivery (82%)</span><strong>PKR 8.9M</strong></div><div style="height:9px;background:var(--sky-100);border-radius:99px;margin-top:.25rem"><div style="width:82%;height:100%;background:var(--orange-500);border-radius:99px"></div></div></div>
          <div><div style="display:flex;justify-content:space-between"><span>Operations (11%)</span><strong>PKR 1.2M</strong></div><div style="height:9px;background:var(--sky-100);border-radius:99px;margin-top:.25rem"><div style="width:11%;height:100%;background:var(--blue-600);border-radius:99px"></div></div></div>
          <div><div style="display:flex;justify-content:space-between"><span>Fundraising (7%)</span><strong>PKR 0.8M</strong></div><div style="height:9px;background:var(--sky-100);border-radius:99px;margin-top:.25rem"><div style="width:7%;height:100%;background:var(--green-600);border-radius:99px"></div></div></div>
        </div>
        <p class="small muted mt-2" style="margin-bottom:0">Reserves carried into 2026: PKR 0.3M — equal to 10 days of program running cost. Our policy targets 30 days by 2028.</p>
      </div>
    </div>
    <div class="grid grid-4 mt-2">
      <div class="tile center reveal"><div class="metric-value" style="color:var(--blue-600);font-size:1.7rem">PKR 8.9M</div><p style="font-size:.88rem">Spent on programs in 2025</p></div>
      <div class="tile center reveal"><div class="metric-value" style="color:var(--blue-600);font-size:1.7rem">1,780</div><p style="font-size:.88rem">Households served in 2025</p></div>
      <div class="tile center reveal"><div class="metric-value" style="color:var(--blue-600);font-size:1.7rem">14</div><p style="font-size:.88rem">Communities served in 2025</p></div>
      <div class="tile center reveal"><div class="metric-value" style="color:var(--blue-600);font-size:1.7rem">0</div><p style="font-size:.88rem">Unresolved audit findings</p></div>
    </div>
  </div>
</section>

<section class="section">
  <div class="container split">
    <div class="reveal">
      <span class="eyebrow">Reports</span>
      <h2>Public reports &amp; policies</h2>
      <p>Published as they are produced. PDFs open in a new tab.</p>
      <div class="card" style="padding:0">
        <ul style="list-style:none;margin:0;padding:0">
          <li style="padding:1rem 1.4rem;border-bottom:1px solid var(--line);display:flex;justify-content:space-between;align-items:center;gap:1rem">
            <span>{{ICON:file}} <strong>Annual Report &amp; Audited Accounts 2025</strong></span>
            <span class="badge badge-green">Published · Sep 2026</span>
          </li>
          <li style="padding:1rem 1.4rem;border-bottom:1px solid var(--line);display:flex;justify-content:space-between;align-items:center;gap:1rem">
            <span>{{ICON:file}} <strong>Flood Response Report — Aug–Sep 2025</strong></span>
            <span class="badge badge-green">Published · Nov 2025</span>
          </li>
          <li style="padding:1rem 1.4rem;border-bottom:1px solid var(--line);display:flex;justify-content:space-between;align-items:center;gap:1rem">
            <span>{{ICON:file}} <strong>Clean Water Phase I Completion Report</strong></span>
            <span class="badge badge-green">Published · Jul 2026</span>
          </li>
          <li style="padding:1rem 1.4rem;border-bottom:1px solid var(--line);display:flex;justify-content:space-between;align-items:center;gap:1rem">
            <span>{{ICON:file}} <strong>Child &amp; Vulnerable Adult Safeguarding Policy</strong></span>
            <span class="badge badge-green">Version 2 · 2026</span>
          </li>
          <li style="padding:1rem 1.4rem;display:flex;justify-content:space-between;align-items:center;gap:1rem">
            <span>{{ICON:file}} <strong>2026 Q3 Management Accounts</strong></span>
            <span class="badge badge-blue">Due · Oct 2026</span>
          </li>
        </ul>
      </div>
      <p class="small muted mt-1">Attach your PDF files to these entries (or ask us to host them) before launch.</p>
    </div>
    <div class="reveal">
      <h3 class="mt-0">How we spend, in practice</h3>
      <ul class="check-list">
        <li>{{ICON:check}} <span><strong>Every distribution is documented.</strong> Beneficiary lists (kept confidential), receipts, photos and GPS points are filed for every activity.</span></li>
        <li>{{ICON:check}} <span><strong>Two-signature spending.</strong> No payment moves without authorisation from two office bearers.</span></li>
        <li>{{ICON:check}} <span><strong>Community verification.</strong> Local committees confirm deliveries before any activity is counted in our reports.</span></li>
        <li>{{ICON:check}} <span><strong>Zakat ledger.</strong> Zakat-designated gifts are tracked separately and spent only on verified zakat-eligible households.</span></li>
      </ul>
      <div class="note mt-2">
        <h4>{{ICON:alert}} Report a concern</h4>
        <span>Seen something that doesn&rsquo;t match our standards? Email <strong>safeguarding@mankindfirst.org</strong> (confidential, read only by the safeguarding lead) or use the <a href="contact.html">contact form</a> marked &ldquo;Safeguarding&rdquo;. Every concern gets a written response within 7 days.</span>
      </div>
    </div>
  </div>
</section>

<section class="section-tight">
  <div class="container">
    <div class="band band-orange reveal">
      <div>
        <h2>Support a foundation you can check</h2>
        <p style="margin:0">Audited books, published reports, verified distributions — we would rather earn trust slowly than win a donation with a claim we cannot prove.</p>
      </div>
      <div class="btn-row">
        <a class="btn btn-primary" href="donate.html">{{ICON:heart}} Donate</a>
      </div>
    </div>
  </div>
</section>
""")

# ==================================================================
# NEWS
# ==================================================================
PAGES_MORE["news.html"] = dict(
  title="News & Updates | Mankind First Foundation",
  desc="News from Mankind First Foundation — flood response reports, clean water projects, learning centers and foundation milestones across South Punjab.",
  body="""
<section class="page-hero">
  <div class="container">
    {{CRUMB}}
    <h1>News &amp; Updates</h1>
    <p class="lead">Milestones, reports and honest reflections — the record of what your support has built.</p>
  </div>
</section>

<section class="section">
  <div class="container">
    <div class="grid grid-3">
      <article class="card reveal">
        <div class="card-photo"><img src="assets/images/youth.jpg" alt="Teenagers learning on laptops at the digital skills center" loading="lazy"></div>
        <div class="card-body">
          <div class="post-meta"><time datetime="2026-09-08">8 Sep 2026</time><span>•</span><span>Education</span></div>
          <h3>Digital skills lab opens cohort 8</h3>
          <p>Forty new students — 22 of them young women — started our eight-week digital skills course in Multan this week. The lab has now trained 340 graduates since 2025, and 61% of tracked graduates report their first online earning within four months. The waiting list for cohort 9 is open.</p>
        </div>
      </article>
      <article class="card reveal">
        <div class="card-photo"><img src="assets/images/story-community.jpg" alt="Volunteers and neighbours planting a tree together in Khanewal" loading="lazy"></div>
        <div class="card-body">
          <div class="post-meta"><time datetime="2026-08-14">14 Aug 2026</time><span>•</span><span>Community</span></div>
          <h3>Independence Day: 120 trees for Khanewal</h3>
          <p>Our volunteers spent 14 August doing what they do best — with the community. 120 saplings planted along four streets in Khanewal, each adopted by a household for watering duty. The street committee named it &ldquo;the shade project&rdquo;: their streets, their trees, their pride.</p>
        </div>
      </article>
      <article class="card reveal">
        <div class="card-photo"><img src="assets/images/program-water.jpg" alt="Children collecting water from a completed hand pump" loading="lazy"></div>
        <div class="card-body">
          <div class="post-meta"><time datetime="2026-07-02">2 Jul 2026</time><span>•</span><span>Water</span></div>
          <h3>Clean Water Phase I complete — all 11 sites verified</h3>
          <p>The final hand pump of Phase I was installed and tested in June, closing out the program: 9 hand pumps and 2 filtration units, 4,100 people with safe water, 24 quality tests passed and 11 caretakers trained. The full completion report is on our Transparency page — and Phase II is now fundraising.</p>
        </div>
      </article>
      <article class="card reveal">
        <div class="card-photo"><img src="assets/images/program-education.jpg" alt="Students at an after-school learning center" loading="lazy"></div>
        <div class="card-body">
          <div class="post-meta"><time datetime="2026-04-19">19 Apr 2026</time><span>•</span><span>Education</span></div>
          <h3>Seventh learning center opens in Bahawalpur</h3>
          <p>Our newest after-school center welcomed its first 85 students this month — books, uniforms and a hot snack included. It is our first center outside the Multan–Khanewal corridor, and the community committee already has 40 more children on its list.</p>
        </div>
      </article>
      <article class="card reveal">
        <div class="card-photo"><img src="assets/images/program-emergency.jpg" alt="Volunteers wading through floodwater during the 2025 response" loading="lazy"></div>
        <div class="card-body">
          <div class="post-meta"><time datetime="2025-11-30">30 Nov 2025</time><span>•</span><span>Relief</span></div>
          <h3>Flood response report published</h3>
          <p>The complete account of our August–September 2025 flood response is now public: 2,300 families reached, 38,900 hot meals, 6 medical camps and every rupee accounted for. Read the numbers, including what we would do differently, on the Transparency page.</p>
        </div>
      </article>
      <article class="card reveal">
        <div class="card-photo"><img src="assets/images/program-food.jpg" alt="Food parcels stacked at a Ramadan distribution" loading="lazy"></div>
        <div class="card-body">
          <div class="post-meta"><time datetime="2025-03-20">20 Mar 2025</time><span>•</span><span>Food</span></div>
          <h3>Ramadan 2025: 1,900 iftar packs in 30 days</h3>
          <p>Ramadan stretched our kitchen and our volunteers — and the community answered. 1,900 iftar packs distributed across Multan and Khanewal, funded in 11 days by 340 individual donors. Our biggest single-month food effort to date.</p>
        </div>
      </article>
    </div>
    <p class="center muted small mt-3 reveal">Full-length articles with photos and documents are added for each milestone as they happen.</p>
  </div>
</section>

<section class="section-tight">
  <div class="container">
    <div class="band band-navy reveal">
      <div>
        <h2>Be first to know</h2>
        <p style="margin:0">Follow our work — or better, join it. The next update could have you in it.</p>
      </div>
      <div class="btn-row">
        <a class="btn btn-accent" href="get-involved.html">Get Involved</a>
      </div>
    </div>
  </div>
</section>
""")
