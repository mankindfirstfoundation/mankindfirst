# Core pages: Home, About, Mission & Values, Programs, Stories
# Realistic, detailed sample content — every figure is editable by the
# foundation owner (see README: "Replace these with your real data").

PAGES_CORE = {}

# ==================================================================
# HOME
# ==================================================================
PAGES_CORE["index.html"] = dict(
  title="Mankind First Foundation | Compassion in Action",
  desc="Mankind First Foundation is a humanitarian NGO based in Multan, Pakistan — food support, education, healthcare, clean water and flood relief across South Punjab since 2024. Over 12,400 people supported.",
  body="""
<!-- ================= HERO ================= -->
<section class="hero">
  <div class="hero-media">
    <img src="assets/images/hero.jpg" alt="Volunteers in blue vests handing food relief boxes to families at an outdoor community distribution point" fetchpriority="high">
  </div>
  <div class="container">
    <div class="hero-content">
      <span class="hero-kicker">{{ICON:heart}} Registered humanitarian foundation · Est. 2024</span>
      <h1>Putting Mankind <span class="accent">First.</span></h1>
      <p class="lead">Compassion in action. Communities supported. Human dignity respected.</p>
      <div class="btn-row mt-2">
        <a class="btn btn-accent" href="donate.html">{{ICON:heart}} Support Our Mission</a>
        <a class="btn btn-ghost-light" href="programs.html">See Our Work {{ICON:arrow}}</a>
      </div>
    </div>
  </div>
</section>

<!-- ================= IMPACT STRIP ================= -->
<section class="section-tight bg-sky">
  <div class="container">
    <div class="grid grid-4">
      <div class="metric reveal" style="background:#fff;border:1px solid var(--line)">
        <div class="metric-value" style="color:var(--blue-600)">12,400+</div>
        <div class="metric-label" style="color:var(--ink-700)">People supported</div>
      </div>
      <div class="metric reveal" style="background:#fff;border:1px solid var(--line)">
        <div class="metric-value" style="color:var(--blue-600)">6,250</div>
        <div class="metric-label" style="color:var(--ink-700)">Food parcels delivered</div>
      </div>
      <div class="metric reveal" style="background:#fff;border:1px solid var(--line)">
        <div class="metric-value" style="color:var(--blue-600)">14</div>
        <div class="metric-label" style="color:var(--ink-700)">Communities served</div>
      </div>
      <div class="metric reveal" style="background:#fff;border:1px solid var(--line)">
        <div class="metric-value" style="color:var(--blue-600)">210</div>
        <div class="metric-label" style="color:var(--ink-700)">Active volunteers</div>
      </div>
    </div>
    <p class="center small muted mt-1">Cumulative figures, March 2024 – September 2026 · verified in our <a href="transparency.html">2025 Annual Report</a></p>
  </div>
</section>

<!-- ================= MISSION ================= -->
<section class="section">
  <div class="container split">
    <div class="reveal">
      <span class="eyebrow">Our mission</span>
      <h2>People at the center of humanitarian action</h2>
      <p class="lead">Mankind First Foundation exists to put people at the center of humanitarian action — supporting dignity, opportunity and practical help for people and communities facing hardship.</p>
      <p>Founded in Multan in 2024, we work across South Punjab side by side with local communities — delivering food support, education, healthcare, clean water and emergency relief with one rule above all: help must never cost a person their dignity.</p>
      <div class="btn-row mt-1">
        <a class="btn btn-primary" href="about.html">About Our Foundation</a>
        <a class="btn-link" href="mission.html">Our mission &amp; values {{ICON:arrow}}</a>
      </div>
    </div>
    <div class="split-photo reveal">
      <img src="assets/images/story-community.jpg" alt="Neighbours and volunteers planting a young tree together on a sunny village street" loading="lazy">
      <span class="photo-caption">Community-led change in Khanewal — planted, watered and owned by the street itself.</span>
    </div>
  </div>
</section>

<!-- ================= PROGRAMS ================= -->
<section class="section bg-sky">
  <div class="container">
    <div class="center narrow mx-auto reveal">
      <span class="eyebrow">What we do</span>
      <h2>Practical help, delivered with dignity</h2>
      <p>Eight program areas covering the essentials of a dignified life — each one active, locally staffed and reported openly.</p>
    </div>
    <div class="grid grid-4 mt-2">
      <a class="card-link reveal" href="programs.html#food">
        <article class="card">
          <div class="card-photo"><img src="assets/images/program-food.jpg" alt="A volunteer handing a box of fresh food supplies to an older man" loading="lazy"></div>
          <div class="card-body">
            <h3>Food &amp; Essential Support</h3>
            <p>6,250 parcels · 11 monthly distribution points</p>
          </div>
        </article>
      </a>
      <a class="card-link reveal" href="programs.html#education">
        <article class="card">
          <div class="card-photo"><img src="assets/images/program-education.jpg" alt="A teacher helping a young student with his exercise book in a bright classroom" loading="lazy"></div>
          <div class="card-body">
            <h3>Education &amp; Learning</h3>
            <p>1,850 students · 7 after-school centers</p>
          </div>
        </article>
      </a>
      <a class="card-link reveal" href="programs.html#health">
        <article class="card">
          <div class="card-photo"><img src="assets/images/program-health.jpg" alt="A nurse checking the blood pressure of an elderly man at a community health camp" loading="lazy"></div>
          <div class="card-body">
            <h3>Health &amp; Wellbeing</h3>
            <p>3,400 patients · 14 free medical camps</p>
          </div>
        </article>
      </a>
      <a class="card-link reveal" href="programs.html#water">
        <article class="card">
          <div class="card-photo"><img src="assets/images/program-water.jpg" alt="Children filling bottles with clean water at a village hand pump" loading="lazy"></div>
          <div class="card-body">
            <h3>Clean Water &amp; Basic Needs</h3>
            <p>9 hand pumps · 4,100 people with safe water</p>
          </div>
        </article>
      </a>
    </div>
    <div class="center mt-2 reveal">
      <a class="btn btn-primary" href="programs.html">Explore All Eight Program Areas {{ICON:arrow}}</a>
    </div>
  </div>
</section>

<!-- ================= STORY / TRUST ================= -->
<section class="section bg-navy">
  <div class="container split rev">
    <div class="split-photo reveal">
      <img src="assets/images/program-family.jpg" alt="A support worker handing a kit of baby supplies and blankets to a young mother" loading="lazy">
    </div>
    <div class="reveal">
      <span class="eyebrow">Why it matters</span>
      <h2>Support that protects dignity</h2>
      <p class="muted">Behind every food box, notebook and health check is a simple idea: help should strengthen people, never diminish them.</p>
      <ul class="check-list">
        <li>{{ICON:check}} <span><strong>Community-led.</strong> Local committees choose needs and verify every distribution.</span></li>
        <li>{{ICON:check}} <span><strong>Dignity-first.</strong> Confidential assessments — no one is singled out for receiving help.</span></li>
        <li>{{ICON:check}} <span><strong>Honest about money.</strong> 82% of every rupee goes to program delivery — audited yearly.</span></li>
      </ul>
      <div class="btn-row mt-2">
        <a class="btn btn-ghost-light" href="transparency.html">See our 2025 financials</a>
      </div>
    </div>
  </div>
</section>

<!-- ================= VOLUNTEER CTA ================= -->
<section class="section-tight">
  <div class="container">
    <div class="band band-orange reveal">
      <div>
        <h2>Give your time. Change someone&rsquo;s day.</h2>
        <p style="margin:0">210 volunteers already power our work — teachers, nurses, students, drivers, designers. Orientation runs every first Saturday at our Multan office.</p>
      </div>
      <div class="btn-row">
        <a class="btn btn-primary" href="get-involved.html">Become a Volunteer</a>
      </div>
    </div>
  </div>
</section>

<!-- ================= DONATE CTA ================= -->
<section class="section bg-navy">
  <div class="container split">
    <div class="reveal">
      <span class="eyebrow">Donate</span>
      <h2>PKR 3,500 feeds a family for a week</h2>
      <p class="muted">That&rsquo;s the average cost of one food parcel — flour, oil, lentils, tea, spices and vegetables for a household of five. Give once or monthly, through GoFundMe or local bank transfer.</p>
      <div class="btn-row mt-1">
        <a class="btn btn-accent" href="donate.html">Donate Now</a>
        <a class="btn btn-ghost-light" href="fundraising.html">About Our Fundraising</a>
      </div>
    </div>
    <div class="reveal">
      <ul class="check-list">
        <li>{{ICON:shield}} <span><strong>Secure giving</strong> — GoFundMe for international donors, bank transfer locally.</span></li>
        <li>{{ICON:eye}} <span><strong>Transparent use</strong> — audited books, published quarterly.</span></li>
        <li>{{ICON:heart}} <span><strong>Dignity guaranteed</strong> — verified by our community committees.</span></li>
      </ul>
    </div>
  </div>
</section>
""")

# ==================================================================
# ABOUT
# ==================================================================
PAGES_CORE["about.html"] = dict(
  title="About Mankind First Foundation | Our Mission & Values",
  desc="Mankind First Foundation is a registered humanitarian NGO founded in Multan, Pakistan in 2024 — serving communities across South Punjab with food, education, health, water and relief programs.",
  body="""
<section class="page-hero">
  <div class="container">
    {{CRUMB}}
    <h1>About Mankind First Foundation</h1>
    <p class="lead">A registered humanitarian foundation from Multan, working across South Punjab since 2024 — built to put people first.</p>
  </div>
</section>

<section class="section">
  <div class="container split">
    <div class="reveal">
      <span class="eyebrow">Who we are</span>
      <h2>From one van and six friends to 210 volunteers</h2>
      <p>Mankind First Foundation began in March 2024, when a small group of friends in Multan rented a van, loaded it with flour bags and cooked meals, and drove to families they knew were going hungry on the city&rsquo;s outskirts. That first weekend fed 60 households — and set the standard for everything since: go yourself, listen first, hand over with respect.</p>
      <p>Today we are a registered foundation with a nine-person core team, a 210-strong volunteer network and programs running in 14 communities across South Punjab — from Multan and Khanewal to Bahawalpur and Dera Ghazi Khan.</p>
      <div class="grid grid-2 mt-2" style="gap:1rem">
        <div class="tile"><h3 style="font-size:1rem">Registered</h3><p style="font-size:.9rem">Societies Registration Act, 1860<br><strong>Reg. No. RP/5907/2024</strong> · Multan</p></div>
        <div class="tile"><h3 style="font-size:1rem">Head office</h3><p style="font-size:.9rem">Second Floor, Al-Hamd Plaza,<br>Bosan Road, Multan, Punjab</p></div>
      </div>
    </div>
    <div class="split-photo reveal">
      <img src="assets/images/program-elderly.jpg" alt="A young volunteer sitting with an elderly grandmother, holding her hands warmly" loading="lazy">
      <span class="photo-caption">Elderly care visit in Vehari — time, attention and respect.</span>
    </div>
  </div>
</section>

<section class="section bg-sky">
  <div class="container">
    <div class="narrow reveal">
      <span class="eyebrow">Why we exist</span>
      <h2>Hardship is human. So is helping.</h2>
      <p class="lead">South Punjab carries some of Pakistan&rsquo;s deepest poverty — and its most generous communities.</p>
      <p>Districts like Muzaffargarh, Rajanpur and DG Khan face recurring floods, stretched schools and clinics, and villages where clean water still means a two-kilometre walk. We exist to close that gap with practical, verified support — and to prove that a small, honest foundation can move a very large needle when the community stands behind it.</p>
    </div>
    <div class="grid grid-3 mt-2">
      <div class="tile reveal">
        <div class="card-icon">{{ICON:users}}</div>
        <h3>Listen first</h3>
        <p>Every program starts with a community jirga — the people who live the need define it, and a local committee verifies every distribution.</p>
      </div>
      <div class="tile reveal">
        <div class="card-icon orange">{{ICON:heart}}</div>
        <h3>Act with dignity</h3>
        <p>Needs assessments stay confidential. No cameras without consent. No family is ever publicly labelled as a beneficiary.</p>
      </div>
      <div class="tile reveal">
        <div class="card-icon green">{{ICON:eye}}</div>
        <h3>Prove it</h3>
        <p>Distribution lists, receipts and photos are filed for every activity. Our books are audited annually — 82% of spending goes to programs.</p>
      </div>
    </div>
  </div>
</section>

<section class="section">
  <div class="container">
    <div class="center narrow mx-auto reveal">
      <span class="eyebrow">Our people</span>
      <h2>The team behind the work</h2>
      <p>Nine core staff, 210 registered volunteers, and a community committee in every district we serve.</p>
    </div>
    <div class="grid grid-3 mt-2">
      <div class="tile reveal"><div class="card-icon">{{ICON:users}}</div><h3>Programs team (4)</h3><p>Plans and runs every distribution, camp and class — including field verification of every beneficiary list.</p></div>
      <div class="tile reveal"><div class="card-icon green">{{ICON:shield}}</div><h3>Safeguarding &amp; compliance (2)</h3><p>Protects the people we serve, screens volunteers, keeps our records and registration in order.</p></div>
      <div class="tile reveal"><div class="card-icon orange">{{ICON:trend}}</div><h3>Fundraising &amp; comms (3)</h3><p>Runs campaigns, manages donor reporting and publishes the numbers — good and bad — every quarter.</p></div>
    </div>
    <div class="center mt-2 reveal">
      <a class="btn btn-primary" href="get-involved.html">Join the volunteer team {{ICON:arrow}}</a>
    </div>
  </div>
</section>

<section class="section">
  <div class="container">
    <div class="narrow mx-auto steps">
      <div class="step reveal">
        <h3>Identify real needs</h3>
        <p>Community committees and door-to-door surveys build a confidential, needs-ranked list before we commit a single rupee.</p>
      </div>
      <div class="step reveal">
        <h3>Plan responsibly</h3>
        <p>Each activity gets a written plan: budget, beneficiary criteria, safeguarding measures and a named field lead.</p>
      </div>
      <div class="step reveal">
        <h3>Deliver with respect</h3>
        <p>Direct, local, and personal — distributions run by volunteers who know the families by name.</p>
      </div>
      <div class="step reveal">
        <h3>Report honestly</h3>
        <p>Counts, costs and photos go into our quarterly updates and annual audit — published on this website.</p>
      </div>
    </div>
  </div>
</section>

<section class="section-tight">
  <div class="container">
    <div class="band band-navy reveal">
      <div>
        <h2>The values behind the name</h2>
        <p style="margin:0">Human dignity. Compassion. Accountability. Community. Inclusion. These are not decorations — they are the test every decision must pass.</p>
      </div>
      <div class="btn-row">
        <a class="btn btn-accent" href="mission.html">Read Our Mission &amp; Values</a>
      </div>
    </div>
  </div>
</section>
""")

# ==================================================================
# MISSION & VALUES
# ==================================================================
PAGES_CORE["mission.html"] = dict(
  title="Our Mission & Values | Mankind First Foundation",
  desc="Human dignity, compassion, accountability, community and inclusion — the five values that guide every program of Mankind First Foundation.",
  body="""
<section class="page-hero">
  <div class="container">
    {{CRUMB}}
    <h1>Our Mission &amp; Values</h1>
    <p class="lead">Why we exist, what we believe, and the promises we make to the people we serve and the people who support us.</p>
  </div>
</section>

<section class="section">
  <div class="container narrow center">
    <span class="eyebrow">Our mission</span>
    <h2>Putting people at the center of humanitarian action</h2>
    <p class="lead">Mankind First Foundation exists to put people at the center of humanitarian action — supporting dignity, opportunity and practical help for people and communities facing hardship.</p>
    <p class="muted">Our vision: communities across South Punjab where no family goes hungry, no child is kept from school by poverty, and no elder is left alone.</p>
  </div>
</section>

<section class="section bg-sky">
  <div class="container">
    <div class="center narrow mx-auto reveal">
      <span class="eyebrow">Our values</span>
      <h2>Five values, one standard</h2>
      <p>Every program, partnership and rupee of support is measured against these commitments.</p>
    </div>
    <div class="grid grid-3 mt-2">
      <div class="tile reveal">
        <div class="card-icon">{{ICON:heart}}</div>
        <h3>Human dignity</h3>
        <p>Every person deserves respect. We listen before we act, and we never use images or stories that exploit hardship for sympathy.</p>
      </div>
      <div class="tile reveal">
        <div class="card-icon orange">{{ICON:sun}}</div>
        <h3>Compassion</h3>
        <p>We respond to real needs with care — quickly where we can, thoughtfully where we must, and always with kindness.</p>
      </div>
      <div class="tile reveal">
        <div class="card-icon green">{{ICON:eye}}</div>
        <h3>Accountability</h3>
        <p>Audited books, published quarterly reports, and community committees who verify every distribution on the ground.</p>
      </div>
      <div class="tile reveal">
        <div class="card-icon">{{ICON:users}}</div>
        <h3>Community</h3>
        <p>Sustainable progress begins with people and local participation. We strengthen what communities already have.</p>
      </div>
      <div class="tile reveal">
        <div class="card-icon">{{ICON:globe}}</div>
        <h3>Inclusion</h3>
        <p>Support reaches people of every faith, ethnicity, gender and age — 41% of everyone we served last year were women, 38% children.</p>
      </div>
      <div class="tile reveal">
        <div class="card-icon green">{{ICON:seedling}}</div>
        <h3>Hope with evidence</h3>
        <p>We believe in hope backed by honest evidence — real help, measured results, and stories told with consent.</p>
      </div>
    </div>
  </div>
</section>

<section class="section">
  <div class="container split">
    <div class="reveal">
      <span class="eyebrow">Our commitments</span>
      <h2>Promises we make to you</h2>
      <p>Whether you are a person we support, a volunteer, or a donor considering your gift — these are the standards you can hold us to.</p>
      <ul class="check-list">
        <li>{{ICON:check}} <span><strong>Safeguarding.</strong> Every volunteer is screened and trained before field work; children&rsquo;s images are published only with guardian consent.</span></li>
        <li>{{ICON:check}} <span><strong>Honest fundraising.</strong> Every campaign has a published budget and a completion report.</span></li>
        <li>{{ICON:check}} <span><strong>Verified impact.</strong> Figures on this site are cumulative, dated and traceable to distribution records.</span></li>
        <li>{{ICON:check}} <span><strong>Respectful storytelling.</strong> Stories are shared with consent, and names are changed when privacy requires it.</span></li>
      </ul>
    </div>
    <div class="split-photo reveal">
      <img src="assets/images/program-women.jpg" alt="Women learning tailoring at a vocational training workshop, an instructor guiding a student" loading="lazy">
      <span class="photo-caption">Tailoring center, Multan — 580 women trained since 2024.</span>
    </div>
  </div>
</section>

<section class="section-tight">
  <div class="container">
    <div class="band band-navy reveal">
      <div>
        <h2>Hold us to it</h2>
        <p style="margin:0">Our Transparency page shows the financials, reports and safeguarding policy behind every promise.</p>
      </div>
      <div class="btn-row">
        <a class="btn btn-accent" href="transparency.html">Transparency &amp; Accountability</a>
      </div>
    </div>
  </div>
</section>
""")

# ==================================================================
# PROGRAMS
# ==================================================================
PAGES_CORE["programs.html"] = dict(
  title="Our Programs | Mankind First Foundation",
  desc="Eight active humanitarian programs across South Punjab, Pakistan — food support, education, healthcare, clean water, family care, elderly support, women & youth empowerment and flood relief.",
  body="""
<section class="page-hero">
  <div class="container">
    {{CRUMB}}
    <h1>What We Do</h1>
    <p class="lead">Eight active programs across 14 communities in South Punjab — each locally staffed, verified and reported openly.</p>
  </div>
</section>

<section class="section">
  <div class="container">
    <div class="grid grid-2">

      <article class="card reveal" id="food">
        <div class="card-photo"><img src="assets/images/program-food.jpg" alt="Hands passing a cardboard box of flour, oil, lentils and fresh vegetables" loading="lazy"></div>
        <div class="card-body">
          <span class="badge badge-green">Active since May 2024</span>
          <h2 style="font-size:1.35rem">Food &amp; Essential Support</h2>
          <p>Monthly food parcels and daily essentials for families facing hardship — distributed through 11 community points across Multan, Khanewal and Vehari.</p>
          <div class="grid grid-3" style="gap:.6rem;margin:.4rem 0">
            <div class="metric" style="background:var(--sky-050);border:1px solid var(--line)"><div class="metric-value" style="color:var(--blue-600);font-size:1.4rem">6,250</div><div class="metric-label" style="color:var(--ink-700);font-size:.78rem">Food parcels</div></div>
            <div class="metric" style="background:var(--sky-050);border:1px solid var(--line)"><div class="metric-value" style="color:var(--blue-600);font-size:1.4rem">720</div><div class="metric-label" style="color:var(--ink-700);font-size:.78rem">Families monthly</div></div>
            <div class="metric" style="background:var(--sky-050);border:1px solid var(--line)"><div class="metric-value" style="color:var(--blue-600);font-size:1.4rem">PKR 3,500</div><div class="metric-label" style="color:var(--ink-700);font-size:.78rem">Cost per parcel</div></div>
          </div>
          <details>
            <summary>How this program works</summary>
            <div class="acc-body" style="padding:0.6rem 0 0">
              <p style="font-size:.95rem">Each parcel carries a week of essentials for a household of five: 10 kg flour, 3 L cooking oil, 2 kg lentils, rice, tea, sugar, spices and seasonal vegetables. Families are identified confidentially by our local committees; parcels are handed over at neutral community points so no household is publicly singled out. During Ramadan the program expands with daily iftar packs.</p>
            </div>
          </details>
        </div>
      </article>

      <article class="card reveal" id="education">
        <div class="card-photo"><img src="assets/images/program-education.jpg" alt="A teacher helping a young student with his exercise book in a bright classroom" loading="lazy"></div>
        <div class="card-body">
          <span class="badge badge-green">Active since Aug 2024</span>
          <h2 style="font-size:1.35rem">Education &amp; Learning</h2>
          <p>After-school learning centers, school kits and fee support that keep children in class — because poverty should never decide who gets to learn.</p>
          <div class="grid grid-3" style="gap:.6rem;margin:.4rem 0">
            <div class="metric" style="background:var(--sky-050);border:1px solid var(--line)"><div class="metric-value" style="color:var(--blue-600);font-size:1.4rem">1,850</div><div class="metric-label" style="color:var(--ink-700);font-size:.78rem">Students supported</div></div>
            <div class="metric" style="background:var(--sky-050);border:1px solid var(--line)"><div class="metric-value" style="color:var(--blue-600);font-size:1.4rem">7</div><div class="metric-label" style="color:var(--ink-700);font-size:.78rem">Learning centers</div></div>
            <div class="metric" style="background:var(--sky-050);border:1px solid var(--line)"><div class="metric-value" style="color:var(--blue-600);font-size:1.4rem">94%</div><div class="metric-label" style="color:var(--ink-700);font-size:.78rem">Still in school after 1 yr</div></div>
          </div>
          <details>
            <summary>How this program works</summary>
            <div class="acc-body" style="padding:0.6rem 0 0">
              <p style="font-size:.95rem">Seven after-school centers — five in Multan, one in Khanewal, one in Bahawalpur — offer two hours of tutoring daily in Urdu, English, maths and science, taught by trained local teachers at a modest stipend. Each enrolled child receives a yearly school kit (books, uniform shoes, bag, stationery). Our retention target is simple: every child who joins stays in school, and our volunteers follow up with families whenever attendance slips.</p>
            </div>
          </details>
        </div>
      </article>

      <article class="card reveal" id="health">
        <div class="card-photo"><img src="assets/images/program-health.jpg" alt="A nurse checking an elderly man's blood pressure at an outdoor community health camp" loading="lazy"></div>
        <div class="card-body">
          <span class="badge badge-green">Active since Jan 2025</span>
          <h2 style="font-size:1.35rem">Health &amp; Wellbeing</h2>
          <p>Free medical camps and mobile clinics bringing check-ups, medicines and referrals to villages far from the nearest hospital.</p>
          <div class="grid grid-3" style="gap:.6rem;margin:.4rem 0">
            <div class="metric" style="background:var(--sky-050);border:1px solid var(--line)"><div class="metric-value" style="color:var(--blue-600);font-size:1.4rem">3,400</div><div class="metric-label" style="color:var(--ink-700);font-size:.78rem">Patients treated</div></div>
            <div class="metric" style="background:var(--sky-050);border:1px solid var(--line)"><div class="metric-value" style="color:var(--blue-600);font-size:1.4rem">14</div><div class="metric-label" style="color:var(--ink-700);font-size:.78rem">Medical camps</div></div>
            <div class="metric" style="background:var(--sky-050);border:1px solid var(--line)"><div class="metric-value" style="color:var(--blue-600);font-size:1.4rem">26</div><div class="metric-label" style="color:var(--ink-700);font-size:.78rem">Volunteer medics</div></div>
          </div>
          <details>
            <summary>How this program works</summary>
            <div class="acc-body" style="padding:0.6rem 0 0">
              <p style="font-size:.95rem">We partner with volunteer doctors and nurses — 26 on our register — to run free day camps: blood pressure and diabetes screening, maternal check-ups, child vaccination guidance and a stocked medicine counter. Patients needing ongoing care get referral letters to partner hospitals in Multan, and our volunteers confirm each referral was actually seen. Average camp cost: PKR 85,000, treating 240–300 patients.</p>
            </div>
          </details>
        </div>
      </article>

      <article class="card reveal" id="water">
        <div class="card-photo"><img src="assets/images/program-water.jpg" alt="Children happily filling bottles and pots with clean water at a village hand pump" loading="lazy"></div>
        <div class="card-body">
          <span class="badge badge-green">Active since Mar 2025</span>
          <h2 style="font-size:1.35rem">Clean Water &amp; Basic Needs</h2>
          <p>Hand pumps and filtration units in water-scarce villages of Muzaffargarh and DG Khan — ending the two-kilometre walk for water.</p>
          <div class="grid grid-3" style="gap:.6rem;margin:.4rem 0">
            <div class="metric" style="background:var(--sky-050);border:1px solid var(--line)"><div class="metric-value" style="color:var(--blue-600);font-size:1.4rem">9</div><div class="metric-label" style="color:var(--ink-700);font-size:.78rem">Hand pumps built</div></div>
            <div class="metric" style="background:var(--sky-050);border:1px solid var(--line)"><div class="metric-value" style="color:var(--blue-600);font-size:1.4rem">2</div><div class="metric-label" style="color:var(--ink-700);font-size:.78rem">Filtration units</div></div>
            <div class="metric" style="background:var(--sky-050);border:1px solid var(--line)"><div class="metric-value" style="color:var(--blue-600);font-size:1.4rem">4,100</div><div class="metric-label" style="color:var(--ink-700);font-size:.78rem">People with safe water</div></div>
          </div>
          <details>
            <summary>How this program works</summary>
            <div class="acc-body" style="padding:0.6rem 0 0">
              <p style="font-size:.95rem">A hand pump (PKR 95,000 installed) serves roughly 45 households; a solar-powered filtration unit (PKR 850,000) serves a whole village with tested, safe drinking water. Every site gets a trained local caretaker, a maintenance fund and twice-yearly water quality testing. Phase II — 25 more hand pumps and 3 filtration units in Muzaffargarh and Rajanpur — is our current fundraising campaign.</p>
            </div>
          </details>
        </div>
      </article>

      <article class="card reveal" id="family">
        <div class="card-photo"><img src="assets/images/program-family.jpg" alt="A support worker giving a young mother a kit of baby supplies and blankets" loading="lazy"></div>
        <div class="card-body">
          <span class="badge badge-green">Active since Sep 2024</span>
          <h2 style="font-size:1.35rem">Children &amp; Family Support</h2>
          <p>Newborn kits, household essentials and a casework pathway for families under pressure — delivered with confidentiality and respect.</p>
          <div class="grid grid-3" style="gap:.6rem;margin:.4rem 0">
            <div class="metric" style="background:var(--sky-050);border:1px solid var(--line)"><div class="metric-value" style="color:var(--blue-600);font-size:1.4rem">480</div><div class="metric-label" style="color:var(--ink-700);font-size:.78rem">Newborn kits</div></div>
            <div class="metric" style="background:var(--sky-050);border:1px solid var(--line)"><div class="metric-value" style="color:var(--blue-600);font-size:1.4rem">320</div><div class="metric-label" style="color:var(--ink-700);font-size:.78rem">Families caseworked</div></div>
            <div class="metric" style="background:var(--sky-050);border:1px solid var(--line)"><div class="metric-value" style="color:var(--blue-600);font-size:1.4rem">PKR 6,000</div><div class="metric-label" style="color:var(--ink-700);font-size:.78rem">Per newborn kit</div></div>
          </div>
          <details>
            <summary>How this program works</summary>
            <div class="acc-body" style="padding:0.6rem 0 0">
              <p style="font-size:.95rem">A newborn kit dresses and warms a baby&rsquo;s first months: clothes, blankets, soap, diapers and a feeding set. For families facing deeper crisis — job loss, illness, a breadwinner&rsquo;s death — our two caseworkers build a six-month support plan connecting them to food support, school fee waivers, skills training and, where needed, partner services beyond our scope.</p>
            </div>
          </details>
        </div>
      </article>

      <article class="card reveal" id="elderly">
        <div class="card-photo"><img src="assets/images/program-elderly.jpg" alt="A volunteer warmly holding the hands of an elderly woman at her doorstep, tea on a tray beside them" loading="lazy"></div>
        <div class="card-body">
          <span class="badge badge-green">Active since Oct 2024</span>
          <h2 style="font-size:1.35rem">Elderly &amp; Vulnerable People</h2>
          <p>Weekly care visits, medicines and winter warmth for elderly neighbours living alone — because no one should spend their last years unseen.</p>
          <div class="grid grid-3" style="gap:.6rem;margin:.4rem 0">
            <div class="metric" style="background:var(--sky-050);border:1px solid var(--line)"><div class="metric-value" style="color:var(--blue-600);font-size:1.4rem">260</div><div class="metric-label" style="color:var(--ink-700);font-size:.78rem">Elders visited weekly</div></div>
            <div class="metric" style="background:var(--sky-050);border:1px solid var(--line)"><div class="metric-value" style="color:var(--blue-600);font-size:1.4rem">610</div><div class="metric-label" style="color:var(--ink-700);font-size:.78rem">Winter blanket kits</div></div>
            <div class="metric" style="background:var(--sky-050);border:1px solid var(--line)"><div class="metric-value" style="color:var(--blue-600);font-size:1.4rem">52</div><div class="metric-label" style="color:var(--ink-700);font-size:.78rem">Weeks running</div></div>
          </div>
          <details>
            <summary>How this program works</summary>
            <div class="acc-body" style="padding:0.6rem 0 0">
              <p style="font-size:.95rem">Pairs of volunteers adopt a small cluster of elders for weekly visits: tea, conversation, medicine pick-ups from the pharmacy, and a check on food and safety at home. Every December, our winter campaign adds quilts, shawls and shawls-and-sweater kits. Referrals for medical care are coordinated with our Health program camps.</p>
            </div>
          </details>
        </div>
      </article>

      <article class="card reveal" id="women-youth">
        <div class="card-photo"><img src="assets/images/program-women.jpg" alt="Women working at sewing machines in a vocational training workshop" loading="lazy"></div>
        <div class="card-body">
          <span class="badge badge-green">Active since Nov 2024</span>
          <h2 style="font-size:1.35rem">Women &amp; Youth Empowerment</h2>
          <p>Four tailoring centers, a digital skills lab and startup support — skills that turn into income, and income that turns into independence.</p>
          <div class="grid grid-3" style="gap:.6rem;margin:.4rem 0">
            <div class="metric" style="background:var(--sky-050);border:1px solid var(--line)"><div class="metric-value" style="color:var(--blue-600);font-size:1.4rem">580</div><div class="metric-label" style="color:var(--ink-700);font-size:.78rem">Women trained</div></div>
            <div class="metric" style="background:var(--sky-050);border:1px solid var(--line)"><div class="metric-value" style="color:var(--blue-600);font-size:1.4rem">340</div><div class="metric-label" style="color:var(--ink-700);font-size:.78rem">Digital skills graduates</div></div>
            <div class="metric" style="background:var(--sky-050);border:1px solid var(--line)"><div class="metric-value" style="color:var(--blue-600);font-size:1.4rem">72%</div><div class="metric-label" style="color:var(--ink-700);font-size:.78rem">Earning within 6 months</div></div>
          </div>
          <details>
            <summary>How this program works</summary>
            <div class="acc-body" style="padding:0.6rem 0 0">
              <p style="font-size:.95rem">Three-month tailoring courses at four centers (two in Multan, one in Khanewal, one in Vehari) end with a free sewing machine for every graduate who completes the course and a business starter kit. Our digital skills lab in Multan runs eight-week evening courses — computer basics, freelancing platforms and online safety — for 40 students per cohort. Graduates get six months of mentoring and access to a shared equipment fund.</p>
            </div>
          </details>
        </div>
      </article>

      <article class="card reveal" id="emergency">
        <div class="card-photo"><img src="assets/images/program-emergency.jpg" alt="Relief volunteers wading through floodwater carrying supply boxes" loading="lazy"></div>
        <div class="card-body">
          <span class="badge badge-green">Active since Jun 2024</span>
          <h2 style="font-size:1.35rem">Emergency &amp; Community Relief</h2>
          <p>Rapid response when floods and disasters strike South Punjab — because the 2025 monsoon showed exactly why this program must exist.</p>
          <div class="grid grid-3" style="gap:.6rem;margin:.4rem 0">
            <div class="metric" style="background:var(--sky-050);border:1px solid var(--line)"><div class="metric-value" style="color:var(--blue-600);font-size:1.4rem">2,300</div><div class="metric-label" style="color:var(--ink-700);font-size:.78rem">Families in flood response</div></div>
            <div class="metric" style="background:var(--sky-050);border:1px solid var(--line)"><div class="metric-value" style="color:var(--blue-600);font-size:1.4rem">38,900</div><div class="metric-label" style="color:var(--ink-700);font-size:.78rem">Hot meals served</div></div>
            <div class="metric" style="background:var(--sky-050);border:1px solid var(--line)"><div class="metric-value" style="color:var(--blue-600);font-size:1.4rem">48 hrs</div><div class="metric-label" style="color:var(--ink-700);font-size:.78rem">First response time</div></div>
          </div>
          <details>
            <summary>How this program works</summary>
            <div class="acc-body" style="padding:0.6rem 0 0">
              <p style="font-size:.95rem">A pre-positioned relief stock (tents, blankets, water purification tablets, dry rations for 500 families) sits at our Multan warehouse through monsoon season. When the August 2025 floods hit Muzaffargarh and Rajanpur, our teams reached the first displaced families within 48 hours, ran six medical camps and served hot meals from a community kitchen for 31 consecutive days. The full response report is on our Transparency page.</p>
            </div>
          </details>
        </div>
      </article>

    </div>
  </div>
</section>

<section class="section">
  <div class="container split">
    <div class="split-photo reveal">
      <img src="assets/images/youth.jpg" alt="Teenagers learning on laptops at a community digital skills center with their instructor" loading="lazy">
      <span class="photo-caption">Digital skills lab, Multan — cohort 8, September 2026.</span>
    </div>
    <div class="reveal">
      <span class="eyebrow">Program spotlight</span>
      <h2>Youth &amp; digital skills</h2>
      <p>Digital literacy is a gateway: to information, to income and to confidence in a connected world. Our Multan lab has graduated 340 young people since 2025 — and the waiting list for the next cohort is 90 names long.</p>
      <ul class="check-list">
        <li>{{ICON:check}} <span><strong>Computer basics</strong> — first-touch skills for school, work and daily life.</span></li>
        <li>{{ICON:check}} <span><strong>Online earning guidance</strong> — freelancing profiles, portfolios and payment setup.</span></li>
        <li>{{ICON:check}} <span><strong>Safe internet habits</strong> — privacy, scam awareness and respectful online behaviour.</span></li>
      </ul>
    </div>
  </div>
</section>

<section class="section-tight">
  <div class="container">
    <div class="band band-orange reveal">
      <div>
        <h2>Every program runs on supporters like you</h2>
        <p style="margin:0">PKR 3,500 feeds a family for a week. PKR 95,000 gives a village water. PKR 12,000 sends a child to school for a year.</p>
      </div>
      <div class="btn-row">
        <a class="btn btn-primary" href="donate.html">{{ICON:heart}} Support a Program</a>
      </div>
    </div>
  </div>
</section>
""")

# ==================================================================
# STORIES / IMPACT
# ==================================================================
PAGES_CORE["stories.html"] = dict(
  title="Impact & Community Stories | Mankind First Foundation",
  desc="Real impact from South Punjab: 12,400+ people supported, verified stories from food, water, education and flood relief programs — reported honestly by Mankind First Foundation.",
  body="""
<section class="page-hero">
  <div class="container">
    {{CRUMB}}
    <h1>Impact &amp; Stories</h1>
    <p class="lead">Real people, verified numbers and honest reporting — this is what your support has done since 2024.</p>
  </div>
</section>

<section class="section-tight">
  <div class="container">
    <div class="note reveal">
      <h4>{{ICON:shield}} How we report</h4>
      <span>Every figure on this page comes from our distribution records and was verified in the <strong>2025 Annual Audit</strong>. Where a story involves a child or a private family, we change names and avoid identifying details — the story is real; the name may not be.</span>
    </div>
  </div>
</section>

<section class="section bg-sky">
  <div class="container">
    <div class="center narrow mx-auto reveal">
      <span class="eyebrow">Verified metrics</span>
      <h2>2025–26 at a glance</h2>
      <p>Cumulative, March 2024 – September 2026.</p>
    </div>
    <div class="grid grid-4 mt-2">
      <div class="metric reveal" style="background:#fff;border:1px solid var(--line)"><div class="metric-value" style="color:var(--blue-600)">12,400+</div><div class="metric-label" style="color:var(--ink-700)">People directly supported</div></div>
      <div class="metric reveal" style="background:#fff;border:1px solid var(--line)"><div class="metric-value" style="color:var(--blue-600)">6,250</div><div class="metric-label" style="color:var(--ink-700)">Food parcels delivered</div></div>
      <div class="metric reveal" style="background:#fff;border:1px solid var(--line)"><div class="metric-value" style="color:var(--blue-600)">38,900</div><div class="metric-label" style="color:var(--ink-700)">Hot meals in flood response</div></div>
      <div class="metric reveal" style="background:#fff;border:1px solid var(--line)"><div class="metric-value" style="color:var(--blue-600)">1,850</div><div class="metric-label" style="color:var(--ink-700)">Children in learning support</div></div>
      <div class="metric reveal" style="background:#fff;border:1px solid var(--line)"><div class="metric-value" style="color:var(--blue-600)">3,400</div><div class="metric-label" style="color:var(--ink-700)">Patients treated free</div></div>
      <div class="metric reveal" style="background:#fff;border:1px solid var(--line)"><div class="metric-value" style="color:var(--blue-600)">4,100</div><div class="metric-label" style="color:var(--ink-700)">People with safe water access</div></div>
      <div class="metric reveal" style="background:#fff;border:1px solid var(--line)"><div class="metric-value" style="color:var(--blue-600)">580</div><div class="metric-label" style="color:var(--ink-700)">Women trained in trades</div></div>
      <div class="metric reveal" style="background:#fff;border:1px solid var(--line)"><div class="metric-value" style="color:var(--blue-600)">210</div><div class="metric-label" style="color:var(--ink-700)">Active volunteers</div></div>
    </div>
    <p class="center small muted mt-2 reveal">Sources: program distribution records · 2025 Annual Report (audited) · verified September 2026</p>
  </div>
</section>

<section class="section">
  <div class="container">
    <div class="center narrow mx-auto reveal">
      <span class="eyebrow">Stories</span>
      <h2>Three lives, three turning points</h2>
      <p>Shared with consent; names changed where privacy requires.</p>
    </div>
    <div class="grid grid-3 mt-2">
      <article class="card reveal">
        <div class="card-photo"><img src="assets/images/program-women.jpg" alt="A woman working at a sewing machine in a training workshop" loading="lazy"></div>
        <div class="card-body">
          <span class="badge badge-orange">Women&rsquo;s empowerment</span>
          <h3>&ldquo;Ayesha&rsquo;s&rdquo; second income</h3>
          <p>Widowed at 34 with three children in Khanewal, Ayesha joined our tailoring course in 2025. She graduated with a free sewing machine, and today stitches for 14 regular customers — earning PKR 18,000 a month. Her eldest is back in school, in uniform, on time.</p>
        </div>
      </article>
      <article class="card reveal">
        <div class="card-photo"><img src="assets/images/program-water.jpg" alt="Children collecting clean water from a hand pump in their village" loading="lazy"></div>
        <div class="card-body">
          <span class="badge badge-orange">Clean water</span>
          <h3>The pump at Chak 381</h3>
          <p>Before March 2025, women of this Muzaffargarh village walked two kilometres twice a day for water that often made their children ill. The hand pump your donations built now serves 45 households. The village committee keeps it maintained; our tests keep it clean.</p>
        </div>
      </article>
      <article class="card reveal">
        <div class="card-photo"><img src="assets/images/program-education.jpg" alt="A teacher helping a student with his exercise book in class" loading="lazy"></div>
        <div class="card-body">
          <span class="badge badge-orange">Education</span>
          <h3>&ldquo;Bilal&rdquo; returns to class</h3>
          <p>Bilal, 11, left school in 2024 to sell vegetables after his father fell ill. Our Multan team met him at a food distribution. Six months later — school kit, fee support and daily tutoring at our center — he topped his class in maths. His teacher calls him &ldquo;the boy who refused to stay behind.&rdquo;</p>
        </div>
      </article>
    </div>
  </div>
</section>

<section class="section bg-navy">
  <div class="container split">
    <div class="reveal">
      <span class="eyebrow">Flood response 2025</span>
      <h2>31 days that defined us</h2>
      <p class="muted">When the August 2025 monsoon floods swept through Muzaffargarh and Rajanpur, our pre-positioned relief stock moved within 48 hours. For 31 days our community kitchen never went cold.</p>
      <ul class="check-list">
        <li>{{ICON:check}} <span><strong>2,300 families</strong> reached with rations, shelter kits and medical help</span></li>
        <li>{{ICON:check}} <span><strong>38,900 hot meals</strong> served from one community kitchen</span></li>
        <li>{{ICON:check}} <span><strong>6 medical camps</strong> run with 26 volunteer medics</span></li>
      </ul>
      <a class="btn btn-ghost-light mt-2" href="transparency.html">Read the full response report</a>
    </div>
    <div class="split-photo reveal">
      <img src="assets/images/program-emergency.jpg" alt="Volunteers carrying relief supplies through floodwater" loading="lazy">
      <span class="photo-caption">Day 3 of the flood response, Muzaffargarh — August 2025.</span>
    </div>
  </div>
</section>

<section class="section">
  <div class="container split rev">
    <div class="split-photo reveal">
      <img src="assets/images/donate-hands.jpg" alt="Hands of different generations stacked together in a gesture of unity and support" loading="lazy">
      <span class="photo-caption">Every hand counts — across generations, borders and beliefs.</span>
    </div>
    <div class="reveal">
      <h2>Write the next chapter with us</h2>
      <p class="lead">The next story on this page could start with your donation today — a food parcel, a water pump, a sewing machine, a school bag.</p>
      <div class="btn-row mt-1">
        <a class="btn btn-accent" href="donate.html">{{ICON:heart}} Donate</a>
        <a class="btn btn-ghost" href="get-involved.html">Volunteer</a>
      </div>
    </div>
  </div>
</section>
""",
)
